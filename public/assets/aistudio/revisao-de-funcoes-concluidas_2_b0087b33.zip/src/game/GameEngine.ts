import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { buildIsaModel, buildPlayerModel, AnimatedCharacter } from './characterModels';
import {
  createFarmTerrain,
  createIsaFarmhouse,
  createBigRedBarn,
  createWindmill,
  createFarmTractor,
  createFarmPlotMesh,
  createCowModel,
  createChickenModel,
  createPigModel,
  createWaterAndBridge,
  createFoliage,
  createAmbientLife,
  createMarketplaceBuilding,
  createCentralTalhoesBuilding,
  createLandPlotMesh,
  AnimatedWorldObjects,
} from './worldModels';
import { FarmPlot, CropType, RemotePlayer, FarmLand } from '../types/game';
import { soundManager } from '../audio/soundManager';

export interface InteractionTarget {
  type: 'plot' | 'animal' | 'isa' | 'barn' | 'market' | 'land' | 'central_talhoes';
  id: string | number;
  label: string;
  icon: string;
  distance: number;
  position: THREE.Vector3;
  landData?: FarmLand;
}

export class GameEngine {
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;
  private isSoftwareGl: boolean;
  private animFrameId: number = 0;
  private container: HTMLElement;

  // Characters
  public isaCharacter: AnimatedCharacter;
  public localPlayer: AnimatedCharacter;
  public remotePlayers: Map<string, AnimatedCharacter> = new Map();

  // World Meshes
  private plotMeshes: Map<number, THREE.Group> = new Map();
  private animatedWorld: AnimatedWorldObjects;
  private interactionRing: THREE.Mesh;

  // Interaction State
  public currentTarget: InteractionTarget | null = null;
  public onInteractionChange?: (target: InteractionTarget | null) => void;
  public onPlayerMove?: (x: number, y: number, z: number, rotation: number, isMoving: boolean) => void;

  // Player Kinematics
  public playerPos: THREE.Vector3 = new THREE.Vector3(0, 0, 2);
  public playerVelocity: THREE.Vector3 = new THREE.Vector3();
  public playerRotation: number = 0;
  public isMoving: boolean = false;
  private moveSpeed: number = 7.0;

  // Camera Settings
  public cameraMode: 'follow' | 'isometric' | 'orbit' = 'follow';
  public cameraOffset: THREE.Vector3 = new THREE.Vector3(0, 9.5, 12);
  private cameraLookTarget: THREE.Vector3 = new THREE.Vector3();

  // Controls State
  private keys: Record<string, boolean> = {};
  public joystickVector: { x: number; y: number } = { x: 0, y: 0 };
  private clock: THREE.Clock = new THREE.Clock();

  // Interactive Coordinates
  public plotCoords: { id: number; x: number; z: number }[] = [
    { id: 0, x: -3.8, z: -3 },
    { id: 1, x: 0, z: -3 },
    { id: 2, x: 3.8, z: -3 },
    { id: 3, x: -3.8, z: 2 },
    { id: 4, x: 3.8, z: 2 },
    { id: 5, x: -3.8, z: 7 },
    { id: 6, x: 0, z: 7 },
    { id: 7, x: 3.8, z: 7 },
  ];

  public animalCoords = [
    { id: 'cow-1', name: 'Mimosa', type: 'cow', x: 13, z: 8 },
    { id: 'cow-2', name: 'Estrela', type: 'cow', x: 17, z: 12 },
    { id: 'chicken-1', name: 'Pipa', type: 'chicken', x: -14, z: -6 },
    { id: 'chicken-2', name: 'Carijó', type: 'chicken', x: -16, z: -9 },
    { id: 'pig-1', name: 'Baconzinho', type: 'pig', x: -7, z: 17 },
  ];

  public isaPosition = new THREE.Vector3(-8.5, 0, -11.5);
  public barnPosition = new THREE.Vector3(15, 0, -14);
  public marketPosition = new THREE.Vector3(-12, 0, 5);
  public centralTalhoesPosition = new THREE.Vector3(8, 0, -6);
  public lands: FarmLand[] = [];
  public landMeshes: Map<string, THREE.Group> = new Map();
  public currentIsaState: string = 'idle';

  public setIsaAnimationState(state: string) {
    this.currentIsaState = state;
  }

  constructor(container: HTMLElement, playerAvatar: string, playerNickname: string, playerLevel: number) {
    this.container = container;

    // Detect Software WebGL
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 1. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xa5f3fc); // Warm sky blue
    this.scene.fog = new THREE.Fog(0xa5f3fc, 45, 95);

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      180
    );
    this.camera.position.set(0, 16, 20);
    this.cameraLookTarget.copy(this.playerPos);

    // 3. Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // 4. Studio Environment & Lighting
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Warm Sun Key Light
    const sunLight = new THREE.DirectionalLight(0xfffbeb, 1.8);
    sunLight.position.set(30, 45, 25);
    sunLight.castShadow = !this.isSoftwareGl;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    sunLight.shadow.camera.near = 10;
    sunLight.shadow.camera.far = 120;
    const d = 32;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    sunLight.shadow.bias = -0.0005;
    sunLight.shadow.normalBias = 0.02;
    this.scene.add(sunLight);

    // Cool Sky / Grass Fill
    const hemiLight = new THREE.HemisphereLight(0xbae6fd, 0x86efac, 0.7);
    this.scene.add(hemiLight);

    // 5. Build World Geometry
    createFarmTerrain(this.scene);
    createIsaFarmhouse(this.scene, -15, -18);
    createBigRedBarn(this.scene, 15, -20);
    const windmillObj = createWindmill(this.scene, -25, 12);
    createFarmTractor(this.scene, 4, -14);
    createMarketplaceBuilding(this.scene, -12, 5);
    createCentralTalhoesBuilding(this.scene, 8, -6);
    createWaterAndBridge(this.scene);
    createFoliage(this.scene);
    const ambientLife = createAmbientLife(this.scene);

    // Animals
    const cows = [
      createCowModel('cow-1', 'Mimosa', 13, 8),
      createCowModel('cow-2', 'Estrela', 17, 12),
    ];
    cows.forEach((c) => this.scene.add(c.root));

    const chickens = [
      createChickenModel('chicken-1', 'Pipa', -14, -6),
      createChickenModel('chicken-2', 'Carijó', -16, -9),
    ];
    chickens.forEach((ch) => this.scene.add(ch.root));

    const pigs = [createPigModel('pig-1', 'Baconzinho', -7, 17)];
    pigs.forEach((p) => this.scene.add(p.root));

    this.animatedWorld = {
      windmillSails: windmillObj.sails,
      cows,
      chickens,
      pigs,
      sheep: [],
      butterflies: ambientLife.butterflies,
      clouds: ambientLife.clouds,
      smokePuffs: ambientLife.smokePuffs,
      update: (time: number) => {
        // Windmill rotation
        if (windmillObj.sails) {
          windmillObj.sails.rotation.z += 0.012;
        }

        // Cow head grazing
        cows.forEach((cow, i) => {
          cow.head.rotation.x = Math.sin(time * 1.5 + i) * 0.15 + 0.1;
          cow.tail.rotation.z = Math.sin(time * 3 + i) * 0.3;
        });

        // Chickens pecking
        chickens.forEach((chk, i) => {
          chk.head.rotation.x = Math.abs(Math.sin(time * 5 + i * 2)) * 0.4;
          chk.root.position.x = chk.root.position.x + Math.sin(time * 0.5 + i) * 0.003;
        });

        // Pigs wiggling
        pigs.forEach((pig, i) => {
          pig.tail.rotation.z = Math.sin(time * 6 + i) * 0.5;
        });

        // Butterflies flapping
        ambientLife.butterflies.forEach((b, i) => {
          const flap = Math.sin(time * 22 + i) * 0.8;
          b.leftWing.rotation.y = flap;
          b.rightWing.rotation.y = -flap;
          b.group.position.x = b.basePos.x + Math.sin(time * 1.2 + i) * 2;
          b.group.position.z = b.basePos.z + Math.cos(time * 1.2 + i) * 2;
          b.group.position.y = b.basePos.y + Math.sin(time * 3 + i) * 0.4;
        });

        // Clouds drifting
        ambientLife.clouds.forEach((cloud) => {
          cloud.position.x += 0.02;
          if (cloud.position.x > 80) cloud.position.x = -80;
        });

        // Smoke puffs
        ambientLife.smokePuffs.forEach((puff) => {
          const t = (time + puff.offset) % 3;
          puff.mesh.position.y = puff.basePos.y + t * 1.4;
          puff.mesh.position.x = puff.basePos.x + Math.sin(t * 2) * 0.3;
          puff.mesh.scale.setScalar(1 + t * 0.8);
          (puff.mesh.material as THREE.Material).opacity = Math.max(0, 0.7 - t * 0.22);
        });
      },
    };

    // 6. Interactive Ground Ring Indicator
    const ringGeo = new THREE.RingGeometry(1.2, 1.4, 24);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.8,
    });
    this.interactionRing = new THREE.Mesh(ringGeo, ringMat);
    this.interactionRing.rotation.x = -Math.PI / 2;
    this.interactionRing.position.y = 0.08;
    this.interactionRing.visible = false;
    this.scene.add(this.interactionRing);

    // 7. Characters Setup
    // Isa
    this.isaCharacter = buildIsaModel();
    this.isaCharacter.root.position.copy(this.isaPosition);
    this.isaCharacter.root.rotation.y = Math.PI / 6; // Facing welcome angle
    this.scene.add(this.isaCharacter.root);

    // Local Player
    this.localPlayer = buildPlayerModel(playerAvatar, playerNickname, playerLevel);
    this.localPlayer.root.position.copy(this.playerPos);
    this.scene.add(this.localPlayer.root);

    // 8. Event Listeners
    this.setupInputs();
    window.addEventListener('resize', this.onResize);

    // 9. Start Game Loop
    this.startLoop();
  }

  // Farm Plots Rendering & Updates
  public updatePlotMeshes(plots: FarmPlot[]) {
    plots.forEach((plot) => {
      const coord = this.plotCoords.find((c) => c.id === plot.id);
      if (!coord) return;

      if (this.plotMeshes.has(plot.id)) {
        const oldMesh = this.plotMeshes.get(plot.id)!;
        this.scene.remove(oldMesh);
      }

      const newMesh = createFarmPlotMesh(
        plot.id,
        coord.x,
        coord.z,
        plot.cropType,
        plot.stage,
        plot.watered
      );
      this.scene.add(newMesh);
      this.plotMeshes.set(plot.id, newMesh);
    });
  }

  // Update Expandable Lands 3D Meshes
  public updateLands(lands: FarmLand[], currentUserId: string) {
    this.lands = lands;
    lands.forEach((land) => {
      if (this.landMeshes.has(land.id)) {
        const oldMesh = this.landMeshes.get(land.id)!;
        this.scene.remove(oldMesh);
      }

      const isMine = land.ownerId === currentUserId;
      const mesh = createLandPlotMesh(
        land.id,
        land.code || 'TALHÃO',
        land.name,
        land.categoryLabel || 'Talhão Agrícola',
        land.x,
        land.z,
        land.width,
        land.depth,
        land.price,
        land.status,
        land.ownerName,
        isMine,
        land.plotsCount || 4
      );
      this.scene.add(mesh);
      this.landMeshes.set(land.id, mesh);
    });
  }

  // Allow live hot-swapping player avatar
  public changeLocalPlayerAvatar(avatarType: string, nickname: string, level: number = 1) {
    this.scene.remove(this.localPlayer.root);
    const newChar = buildPlayerModel(avatarType, nickname, level);
    newChar.root.position.copy(this.playerPos);
    newChar.root.rotation.y = this.playerRotation;
    this.scene.add(newChar.root);
    this.localPlayer = newChar;
  }

  // Synchronize Remote Multiplayer Players
  public updateRemotePlayer(p: RemotePlayer) {
    if (!this.remotePlayers.has(p.id)) {
      const remote = buildPlayerModel(p.avatar || 'leo', p.nickname, 1);
      remote.root.position.set(p.x, p.y, p.z);
      remote.root.rotation.y = p.rotation;
      this.scene.add(remote.root);
      this.remotePlayers.set(p.id, remote);
    } else {
      const remote = this.remotePlayers.get(p.id)!;
      // Smooth interpolation to new position
      remote.root.position.lerp(new THREE.Vector3(p.x, p.y, p.z), 0.35);
      remote.root.rotation.y = THREE.MathUtils.damp(remote.root.rotation.y, p.rotation, 15, 0.016);
      remote.updateAnimation(this.clock.getElapsedTime(), p.isMoving);

      if (p.message && Date.now() - p.message.time < 6000) {
        remote.setChatBubble(p.message.text);
      } else {
        remote.setChatBubble(null);
      }
    }
  }

  public removeRemotePlayer(id: string) {
    if (this.remotePlayers.has(id)) {
      const remote = this.remotePlayers.get(id)!;
      this.scene.remove(remote.root);
      this.remotePlayers.delete(id);
    }
  }

  private setupInputs() {
    window.addEventListener('keydown', (e) => {
      this.keys[e.key.toLowerCase()] = true;
    });

    window.addEventListener('keyup', (e) => {
      this.keys[e.key.toLowerCase()] = false;
    });

    window.addEventListener('blur', () => {
      this.keys = {};
      this.joystickVector = { x: 0, y: 0 };
    });
  }

  private onResize = () => {
    if (!this.container) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  private checkInteractions() {
    let closestTarget: InteractionTarget | null = null;
    let minDistance = 3.6; // Max interaction distance

    // Check Farm Plots
    for (const p of this.plotCoords) {
      const plotPos = new THREE.Vector3(p.x, 0, p.z);
      const dist = this.playerPos.distanceTo(plotPos);
      if (dist < minDistance) {
        minDistance = dist;
        closestTarget = {
          type: 'plot',
          id: p.id,
          label: `Talhão #${p.id + 1}`,
          icon: '🌱',
          distance: dist,
          position: plotPos,
        };
      }
    }

    // Check Animals
    for (const a of this.animalCoords) {
      const aPos = new THREE.Vector3(a.x, 0, a.z);
      const dist = this.playerPos.distanceTo(aPos);
      if (dist < minDistance) {
        minDistance = dist;
        closestTarget = {
          type: 'animal',
          id: a.id,
          label: `${a.name} (${a.type === 'cow' ? 'Vaca' : a.type === 'chicken' ? 'Galinha' : 'Porco'})`,
          icon: a.type === 'cow' ? '🐮' : a.type === 'chicken' ? '🐔' : '🐷',
          distance: dist,
          position: aPos,
        };
      }
    }

    // Check Isa
    const isaDist = this.playerPos.distanceTo(this.isaPosition);
    if (isaDist < minDistance) {
      minDistance = isaDist;
      closestTarget = {
        type: 'isa',
        id: 'isa',
        label: 'Conversar com a Isa',
        icon: '🌟',
        distance: isaDist,
        position: this.isaPosition,
      };
    }

    // Check Barn Door
    const barnDist = this.playerPos.distanceTo(this.barnPosition);
    if (barnDist < minDistance) {
      minDistance = barnDist;
      closestTarget = {
        type: 'barn',
        id: 'barn',
        label: 'Celeiro da Fazenda',
        icon: '📦',
        distance: barnDist,
        position: this.barnPosition,
      };
    }

    // Check Marketplace
    const marketDist = this.playerPos.distanceTo(this.marketPosition);
    if (marketDist < 4.2 && marketDist < minDistance) {
      minDistance = marketDist;
      closestTarget = {
        type: 'market',
        id: 'market',
        label: 'Mercado da Fazendinha (Compradores & Feira)',
        icon: '🏪',
        distance: marketDist,
        position: this.marketPosition,
      };
    }

    // Check Central de Talhões
    const centralDist = this.playerPos.distanceTo(this.centralTalhoesPosition);
    if (centralDist < 4.5 && centralDist < minDistance) {
      minDistance = centralDist;
      closestTarget = {
        type: 'central_talhoes',
        id: 'central-talhoes',
        label: 'Central de Talhões (Comprar Terras)',
        icon: '🗺️',
        distance: centralDist,
        position: this.centralTalhoesPosition,
      };
    }

    // Check Expandable Lands
    for (const land of this.lands) {
      const signPos = new THREE.Vector3(land.x, 0, land.z + land.depth / 2 + 0.3);
      const landDist = this.playerPos.distanceTo(signPos);
      if (landDist < 4.2 && landDist < minDistance) {
        minDistance = landDist;
        closestTarget = {
          type: 'land',
          id: land.id,
          label: land.status === 'owned' ? `Minha Fazenda (${land.name})` : `Comprar Terreno (${land.price} 🪙)`,
          icon: '🗺️',
          distance: landDist,
          position: signPos,
          landData: land,
        };
      }
    }

    if (
      (!this.currentTarget && closestTarget) ||
      (this.currentTarget && !closestTarget) ||
      (this.currentTarget && closestTarget && this.currentTarget.id !== closestTarget.id)
    ) {
      this.currentTarget = closestTarget;
      this.onInteractionChange?.(closestTarget);

      if (closestTarget) {
        this.interactionRing.position.set(
          closestTarget.position.x,
          0.08,
          closestTarget.position.z
        );
        this.interactionRing.visible = true;
      } else {
        this.interactionRing.visible = false;
      }
    }

    // Pulse interaction ring
    if (this.interactionRing.visible) {
      const pulse = 1.0 + Math.sin(this.clock.getElapsedTime() * 6) * 0.12;
      this.interactionRing.scale.set(pulse, pulse, pulse);
    }
  }

  private updateMovement(delta: number) {
    let moveX = 0;
    let moveZ = 0;

    // Keyboard (WASD & Arrows)
    if (this.keys['w'] || this.keys['arrowup']) moveZ -= 1;
    if (this.keys['s'] || this.keys['arrowdown']) moveZ += 1;
    if (this.keys['a'] || this.keys['arrowleft']) moveX -= 1;
    if (this.keys['d'] || this.keys['arrowright']) moveX += 1;

    // Mobile Virtual Joystick
    if (Math.abs(this.joystickVector.x) > 0.05 || Math.abs(this.joystickVector.y) > 0.05) {
      moveX += this.joystickVector.x;
      moveZ += this.joystickVector.y;
    }

    const inputLength = Math.hypot(moveX, moveZ);
    this.isMoving = inputLength > 0.1;

    if (this.isMoving) {
      // Normalize input
      const normX = moveX / inputLength;
      const normZ = moveZ / inputLength;

      // Target rotation towards movement
      const targetAngle = Math.atan2(normX, normZ);
      this.playerRotation = THREE.MathUtils.damp(this.playerRotation, targetAngle, 16, delta);

      // Velocity
      const speed = this.moveSpeed * Math.min(inputLength, 1.0);
      this.playerVelocity.set(normX * speed, 0, normZ * speed);

      // Move player position
      this.playerPos.x += this.playerVelocity.x * delta;
      this.playerPos.z += this.playerVelocity.z * delta;

      // Clamp inside farm boundary
      this.playerPos.x = THREE.MathUtils.clamp(this.playerPos.x, -45, 45);
      this.playerPos.z = THREE.MathUtils.clamp(this.playerPos.z, -45, 45);

      // Footstep sound tick
      if (Math.random() < 0.15) {
        soundManager.playFootstep();
      }

      this.onPlayerMove?.(
        this.playerPos.x,
        this.playerPos.y,
        this.playerPos.z,
        this.playerRotation,
        true
      );
    } else {
      this.playerVelocity.set(0, 0, 0);
      this.onPlayerMove?.(
        this.playerPos.x,
        this.playerPos.y,
        this.playerPos.z,
        this.playerRotation,
        false
      );
    }

    // Sync player 3D mesh
    this.localPlayer.root.position.copy(this.playerPos);
    this.localPlayer.root.rotation.y = this.playerRotation;
    this.localPlayer.updateAnimation(this.clock.getElapsedTime(), this.isMoving);

    // Isa idle animation and greeting
    this.isaCharacter.updateAnimation(this.clock.getElapsedTime(), false, 1, this.currentIsaState);

    // Camera follow with silky exponential damping
    const targetCamX = this.playerPos.x + this.cameraOffset.x;
    const targetCamY = this.playerPos.y + this.cameraOffset.y;
    const targetCamZ = this.playerPos.z + this.cameraOffset.z;

    this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, targetCamX, 6, delta);
    this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, targetCamY, 6, delta);
    this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, targetCamZ, 6, delta);

    this.cameraLookTarget.x = THREE.MathUtils.damp(this.cameraLookTarget.x, this.playerPos.x, 8, delta);
    this.cameraLookTarget.y = THREE.MathUtils.damp(this.cameraLookTarget.y, this.playerPos.y + 1.2, 8, delta);
    this.cameraLookTarget.z = THREE.MathUtils.damp(this.cameraLookTarget.z, this.playerPos.z, 8, delta);

    this.camera.lookAt(this.cameraLookTarget);
  }

  private startLoop() {
    const tick = () => {
      const rawDt = this.clock.getDelta();
      const delta = Math.min(rawDt, 0.05);
      const time = this.clock.getElapsedTime();

      this.updateMovement(delta);
      this.checkInteractions();
      this.animatedWorld.update(time);

      this.renderer.render(this.scene, this.camera);
      this.animFrameId = requestAnimationFrame(tick);
    };

    this.animFrameId = requestAnimationFrame(tick);
  }

  public dispose() {
    cancelAnimationFrame(this.animFrameId);
    window.removeEventListener('resize', this.onResize);
    this.renderer.dispose();
    if (this.container && this.renderer.domElement) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
