import React from 'react';
import isaImg from '../assets/isa_portrait.jpg';
import { IsaMission } from '../types/game';
import { soundManager } from '../audio/soundManager';

interface IsaDialogueModalProps {
  isOpen: boolean;
  onClose: () => void;
  missions: IsaMission[];
  onClaimReward: (missionId: string) => void;
  onGiveFreeSeeds: () => void;
}

export const IsaDialogueModal: React.FC<IsaDialogueModalProps> = ({
  isOpen,
  onClose,
  missions,
  onClaimReward,
  onGiveFreeSeeds,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 pointer-events-auto">
      <div className="bg-white border-4 border-pink-400 rounded-3xl max-w-xl w-full p-5 sm:p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-150">
        <button
          onClick={() => {
            soundManager.playPop();
            onClose();
          }}
          className="absolute top-4 right-4 bg-pink-100 hover:bg-pink-200 text-pink-900 font-black rounded-full w-9 h-9 flex items-center justify-center border-2 border-pink-400 cursor-pointer"
        >
          ✕
        </button>

        {/* Isa Portrait Header */}
        <div className="flex items-center gap-4 mb-4">
          <div className="relative shrink-0">
            <img
              src={isaImg}
              alt="Isa"
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-full border-4 border-pink-400 shadow-lg object-cover"
            />
            <span className="absolute -bottom-1 -right-1 bg-amber-400 text-amber-950 text-xs font-black px-2 py-0.5 rounded-full border border-white shadow">
              ⭐ Isa
            </span>
          </div>

          <div>
            <h3 className="text-xl sm:text-2xl font-black text-pink-950 flex items-center gap-2">
              Conversar com a Isa 🌻
            </h3>
            <p className="text-sm text-pink-800 font-semibold italic mt-0.5">
              &quot;Olá, meu amigo! Adoro quando você vem me ajudar na roça! Veja só o que podemos fazer hoje:&quot;
            </p>
          </div>
        </div>

        {/* Missions Section */}
        <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-1">
          <h4 className="text-xs font-black uppercase tracking-wider text-pink-800">
            Missões e Tarefas da Fazendinha:
          </h4>

          {missions.map((m) => {
            const isFinished = m.currentCount >= m.requiredCount;
            return (
              <div
                key={m.id}
                className={`p-3.5 rounded-2xl border-2 transition ${
                  m.claimed
                    ? 'bg-emerald-50 border-emerald-300 opacity-80'
                    : isFinished
                    ? 'bg-amber-50 border-amber-400 shadow-md ring-2 ring-amber-300'
                    : 'bg-pink-50/60 border-pink-200'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h5 className="font-black text-sm text-pink-950 flex items-center gap-1.5">
                      {m.claimed ? '✅' : isFinished ? '🎉' : '📌'} {m.title}
                    </h5>
                    <p className="text-xs text-pink-900 mt-0.5">{m.description}</p>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-xs font-black text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full border border-amber-300">
                      +{m.rewardCoins} 🪙 +{m.rewardXp} XP
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="mt-2.5 flex items-center gap-2">
                  <div className="flex-1 bg-pink-200 rounded-full h-2.5 overflow-hidden">
                    <div
                      className={`h-full transition-all duration-300 ${
                        isFinished ? 'bg-emerald-500' : 'bg-pink-500'
                      }`}
                      style={{
                        width: `${Math.min(100, (m.currentCount / m.requiredCount) * 100)}%`,
                      }}
                    />
                  </div>
                  <span className="text-xs font-bold text-pink-950">
                    {m.currentCount}/{m.requiredCount}
                  </span>

                  {isFinished && !m.claimed && (
                    <button
                      onClick={() => {
                        onClaimReward(m.id);
                      }}
                      className="ml-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-amber-950 font-black text-xs px-3 py-1.5 rounded-xl shadow border border-amber-600 cursor-pointer animate-bounce"
                    >
                      Resgatar Recompensa! 🎁
                    </button>
                  )}

                  {m.claimed && (
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md">
                      Concluída
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Free Seed Gift from Isa */}
        <div className="mt-4 pt-3 border-t border-pink-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-pink-800 font-semibold text-center sm:text-left">
            Ficou sem sementes? A Isa te dá 3 sementes de milho de presente!
          </p>
          <button
            onClick={() => {
              soundManager.playPop();
              onGiveFreeSeeds();
            }}
            className="bg-pink-500 hover:bg-pink-600 text-white font-extrabold text-xs px-4 py-2 rounded-xl shadow border border-pink-700 cursor-pointer shrink-0"
          >
            🎁 Ganhar Sementes da Isa
          </button>
        </div>
      </div>
    </div>
  );
};
