import React, { useState } from 'react';
import { PlayerProfile, CommunityGoal, IsaMission } from '../types/game';
import { InteractionTarget } from '../game/GameEngine';
import { VirtualJoystick } from './VirtualJoystick';
import { soundManager } from '../audio/soundManager';
import { IsaReactionBanner } from './IsaReactionBanner';

interface HUDProps {
  player: PlayerProfile;
  communityGoal: CommunityGoal;
  activeMission?: IsaMission;
  interactionTarget: InteractionTarget | null;
  onInteract: () => void;
  onOpenInventory: () => void;
  onOpenShop: () => void;
  onOpenMarket: (tab?: 'orders' | 'buy' | 'sell' | 'create') => void;
  onOpenOrders: () => void;
  onOpenLands: () => void;
  onOpenCentralTalhoes?: () => void;
  onOpenMyPlots: () => void;
  onOpenMyFarm: () => void;
  onOpenAvatarCustomizer: () => void;
  onOpenCommunityGoal: () => void;
  onOpenChat: () => void;
  onOpenIsaDialogue: () => void;
  onOpenAdmin: () => void;
  onJoystickMove: (vector: { x: number; y: number }) => void;
  playersOnlineCount: number;
  onlinePlayerNames: string[];
  isMuted: boolean;
  onToggleMute: () => void;
  floatingAlert?: string | null;
  isaSubtitles?: { text: string; animation: any } | null;
  onDismissSubtitles?: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  player,
  communityGoal,
  activeMission,
  interactionTarget,
  onInteract,
  onOpenInventory,
  onOpenShop,
  onOpenMarket,
  onOpenOrders,
  onOpenLands,
  onOpenCentralTalhoes,
  onOpenMyPlots,
  onOpenMyFarm,
  onOpenAvatarCustomizer,
  onOpenCommunityGoal,
  onOpenChat,
  onOpenIsaDialogue,
  onOpenAdmin,
  onJoystickMove,
  playersOnlineCount,
  onlinePlayerNames,
  isMuted,
  onToggleMute,
  floatingAlert,
  isaSubtitles,
  onDismissSubtitles,
}) => {
  const [isDockCollapsed, setIsDockCollapsed] = useState(false);
  const [showPlayersList, setShowPlayersList] = useState(false);

  const xpPercent = Math.min(100, Math.round((player.xp / player.nextLevelXp) * 100));

  return (
    <div className="absolute inset-0 pointer-events-none select-none flex flex-col justify-between p-3 md:p-5 z-20 overflow-hidden font-['Nunito',sans-serif]">
      {/* 1. TOP CLUSTER */}
      <div className="w-full flex items-start justify-between gap-2 pointer-events-none">
        {/* Left: Player Profile & Level */}
        <div className="flex items-center gap-3 bg-white/95 px-3.5 py-2 rounded-2xl shadow-lg border-2 border-amber-300 pointer-events-auto">
          <div className="w-10 h-10 rounded-full bg-amber-400 flex items-center justify-center text-2xl border-2 border-white shadow-sm shrink-0">
            {player.avatar === 'leo' ? '👦' : player.avatar === 'nina' ? '👧' : player.avatar === 'theo' ? '🧢' : '🌸'}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-amber-950 text-sm">{player.nickname}</span>
              <span className="bg-amber-500 text-white font-extrabold text-[11px] px-2 py-0.5 rounded-full shadow-xs">
                Nv. {player.level}
              </span>
            </div>

            {/* XP Bar */}
            <div className="w-24 sm:w-32 bg-amber-200 rounded-full h-2 mt-1 overflow-hidden">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                style={{ width: `${xpPercent}%` }}
              />
            </div>
            <span className="text-[10px] text-amber-700 font-bold tabular-nums">
              {player.xp}/{player.nextLevelXp} XP
            </span>
          </div>
        </div>

        {/* Center: Isa Active Mission Banner */}
        {activeMission && (
          <button
            onClick={() => {
              soundManager.playPop();
              onOpenIsaDialogue();
            }}
            className="hidden sm:flex items-center gap-2 bg-pink-500/95 hover:bg-pink-600 text-white px-4 py-2 rounded-2xl shadow-lg border-2 border-pink-300 pointer-events-auto cursor-pointer transition transform active:scale-95 max-w-sm"
          >
            <span className="text-xl shrink-0">⭐</span>
            <div className="text-left overflow-hidden">
              <span className="text-[11px] font-black uppercase text-pink-200 block">
                Missão da Isa:
              </span>
              <span className="text-xs font-bold truncate block">
                {activeMission.title} ({activeMission.currentCount}/{activeMission.requiredCount})
              </span>
            </div>
          </button>
        )}

        {/* Right: Coins & Online Counter */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Coins Pill */}
          <div className="flex items-center gap-1.5 bg-white/95 px-3 py-1.5 rounded-2xl shadow-lg border-2 border-amber-300 text-amber-950 font-black text-sm">
            <span className="text-lg">🪙</span>
            <span className="tabular-nums">{player.coins}</span>
          </div>

          {/* Online Players Pill */}
          <button
            onClick={() => {
              soundManager.playPop();
              setShowPlayersList(!showPlayersList);
            }}
            className="flex items-center gap-1.5 bg-emerald-500 hover:bg-emerald-600 text-white px-3 py-1.5 rounded-2xl shadow-lg border-2 border-emerald-300 font-extrabold text-xs cursor-pointer transition"
          >
            <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
            <span className="tabular-nums">{playersOnlineCount}</span>
            <span className="hidden md:inline">Online</span>
          </button>
        </div>
      </div>

      {/* Online Players Dropdown Popup */}
      {showPlayersList && (
        <div className="absolute top-16 right-4 bg-white/95 border-3 border-emerald-400 rounded-2xl p-3 shadow-xl pointer-events-auto w-52 z-30">
          <div className="flex items-center justify-between pb-1 border-b border-emerald-200 mb-2">
            <span className="text-xs font-black text-emerald-950">Fazendeiros Conectados:</span>
            <button
              onClick={() => setShowPlayersList(false)}
              className="text-xs font-bold text-gray-500 hover:text-gray-800"
            >
              ✕
            </button>
          </div>
          <div className="space-y-1.5 text-xs text-emerald-900 font-bold max-h-40 overflow-y-auto">
            <div className="flex items-center gap-1.5 text-amber-800">
              <span>⭐</span>
              <span>Isa (Anfitriã)</span>
            </div>
            <div className="flex items-center gap-1.5 text-emerald-700">
              <span>👤</span>
              <span>{player.nickname} (Você)</span>
            </div>
            {onlinePlayerNames.map((name, i) => (
              <div key={i} className="flex items-center gap-1.5">
                <span>🌱</span>
                <span>{name}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. FLOATING ALERT (e.g. "Chuva mágica ativada!") */}
      {floatingAlert && (
        <div className="self-center bg-amber-400/95 text-amber-950 font-black text-sm px-6 py-2 rounded-full shadow-2xl border-2 border-amber-600 animate-bounce pointer-events-none">
          {floatingAlert}
        </div>
      )}

      {/* 3. CONTEXTUAL PROMPT / INTERACTION BUTTON (Center Lower) */}
      {interactionTarget && (
        <div className="self-center flex flex-col items-center gap-2 mb-2 pointer-events-auto">
          <button
            onClick={() => {
              soundManager.playPop();
              onInteract();
            }}
            className="flex items-center gap-2.5 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-500 hover:to-yellow-500 text-amber-950 font-black text-base md:text-lg px-6 py-3.5 rounded-3xl shadow-2xl border-3 border-white transform active:scale-95 transition cursor-pointer animate-pulse"
          >
            <span className="text-2xl">{interactionTarget.icon}</span>
            <span>{interactionTarget.label}</span>
            <span className="text-xs bg-amber-950 text-white px-2 py-0.5 rounded-lg ml-1 font-extrabold hidden sm:inline">
              [E]
            </span>
          </button>
        </div>
      )}

      {/* 4. BOTTOM CONTROLS & DOCK */}
      <div className="w-full flex items-end justify-between pointer-events-none">
        {/* Left: Mobile Touch Virtual Joystick */}
        <div className="pointer-events-auto pb-1">
          <VirtualJoystick onMove={onJoystickMove} />
        </div>

        {/* Center: Unified Collapsible Glass Control Dock */}
        <div className="flex flex-col items-center pointer-events-auto">
          {/* Dock Collapse / Expand Toggle */}
          <button
            onClick={() => {
              soundManager.playPop();
              setIsDockCollapsed(!isDockCollapsed);
            }}
            className="bg-amber-200/95 hover:bg-amber-300 text-amber-950 text-[11px] font-black px-3 py-1 rounded-t-xl border-t border-x border-amber-400 shadow cursor-pointer mb-[-1px] transition"
          >
            {isDockCollapsed ? '▴ Abrir Menu' : '▾ Esconder Menu'}
          </button>

          {!isDockCollapsed && (
            <div className="flex items-center gap-1 sm:gap-1.5 bg-white/95 px-2.5 py-2 rounded-2xl shadow-xl border-3 border-amber-400 max-w-[85vw] sm:max-w-none overflow-x-auto">
              {/* Minha Fazenda */}
              <button
                onClick={() => {
                  soundManager.playPop();
                  onOpenMyFarm();
                }}
                className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-amber-50 hover:bg-amber-200 text-amber-950 font-bold text-xs transition cursor-pointer min-w-12 sm:min-w-14 shrink-0"
                title="Minha Fazenda Principal"
              >
                <span className="text-xl">🏡</span>
                <span className="text-[10px] sm:text-[11px] whitespace-nowrap">Fazenda</span>
              </button>

              {/* Meus Talhões */}
              <button
                onClick={() => {
                  soundManager.playPop();
                  onOpenMyPlots();
                }}
                className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-200 text-emerald-950 font-bold text-xs transition cursor-pointer min-w-12 sm:min-w-14 shrink-0"
                title="Gerenciar Meus Talhões Agrícolas"
              >
                <span className="text-xl">🌾</span>
                <span className="text-[10px] sm:text-[11px] whitespace-nowrap">Meus Talhões</span>
              </button>

              {/* Mercado */}
              <button
                onClick={() => {
                  soundManager.playPop();
                  onOpenMarket('buy');
                }}
                className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-amber-50 hover:bg-amber-200 text-amber-950 font-bold text-xs transition cursor-pointer min-w-12 sm:min-w-14 shrink-0"
                title="Mercado & Feira"
              >
                <span className="text-xl">🏪</span>
                <span className="text-[10px] sm:text-[11px] whitespace-nowrap">Mercado</span>
              </button>

              {/* Pedidos dos Compradores */}
              <button
                onClick={() => {
                  soundManager.playPop();
                  onOpenOrders();
                }}
                className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-yellow-50 hover:bg-yellow-200 text-amber-950 font-bold text-xs transition cursor-pointer min-w-12 sm:min-w-14 shrink-0 relative"
                title="Pedidos de Compradores (NPCs)"
              >
                <span className="text-xl">📋</span>
                <span className="text-[10px] sm:text-[11px] whitespace-nowrap">Pedidos</span>
                <span className="absolute top-0 right-1 w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              </button>

              {/* Mochila */}
              <button
                onClick={() => {
                  soundManager.playPop();
                  onOpenInventory();
                }}
                className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-amber-50 hover:bg-amber-200 text-amber-950 font-bold text-xs transition cursor-pointer min-w-12 sm:min-w-14 shrink-0"
                title="Mochila e Inventário"
              >
                <span className="text-xl">🎒</span>
                <span className="text-[10px] sm:text-[11px] whitespace-nowrap">Mochila</span>
              </button>

              {/* Comprar Talhões (Central de Talhões) */}
              <button
                onClick={() => {
                  soundManager.playPop();
                  onOpenCentralTalhoes?.();
                }}
                className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-emerald-100 hover:bg-emerald-200 text-emerald-950 font-bold text-xs transition cursor-pointer min-w-12 sm:min-w-14 shrink-0"
                title="Central de Talhões: Comprar novos lotes"
              >
                <span className="text-xl">🗺️</span>
                <span className="text-[10px] sm:text-[11px] whitespace-nowrap">Comprar Talhões</span>
              </button>

              {/* Missões / Isa */}
              <button
                onClick={() => {
                  soundManager.playPop();
                  onOpenIsaDialogue();
                }}
                className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-pink-100 hover:bg-pink-200 text-pink-950 font-bold text-xs transition cursor-pointer min-w-12 sm:min-w-14 shrink-0"
                title="Missões e Conversas com a Isa"
              >
                <span className="text-xl">⭐</span>
                <span className="text-[10px] sm:text-[11px] whitespace-nowrap">Missões</span>
              </button>

              {/* Personalizar Avatar */}
              <button
                onClick={() => {
                  soundManager.playPop();
                  onOpenAvatarCustomizer();
                }}
                className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-blue-50 hover:bg-blue-200 text-blue-950 font-bold text-xs transition cursor-pointer min-w-12 sm:min-w-14 shrink-0"
                title="Trocar Avatar 3D (12 Personagens)"
              >
                <span className="text-xl">👤</span>
                <span className="text-[10px] sm:text-[11px] whitespace-nowrap">Avatar</span>
              </button>

              {/* Meta Coletiva */}
              <button
                onClick={() => {
                  soundManager.playPop();
                  onOpenCommunityGoal();
                }}
                className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-amber-50 hover:bg-amber-200 text-amber-950 font-bold text-xs transition cursor-pointer min-w-11 sm:min-w-12 shrink-0 relative"
                title="Meta Coletiva da Fazendinha"
              >
                <span className="text-xl">🌽</span>
                <span className="text-[10px] sm:text-[11px] whitespace-nowrap">Meta</span>
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping" />
              </button>

              {/* Chat */}
              <button
                onClick={() => {
                  soundManager.playPop();
                  onOpenChat();
                }}
                className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-amber-50 hover:bg-amber-200 text-amber-950 font-bold text-xs transition cursor-pointer min-w-11 sm:min-w-12 shrink-0"
                title="Chat Rápido Multiplayer"
              >
                <span className="text-xl">💬</span>
                <span className="text-[10px] sm:text-[11px] whitespace-nowrap">Falar</span>
              </button>

              {/* Som / Voz */}
              <button
                onClick={() => {
                  soundManager.playPop();
                  onToggleMute();
                }}
                className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-amber-50 hover:bg-amber-200 text-amber-950 font-bold text-xs transition cursor-pointer min-w-11 sm:min-w-12 shrink-0"
                title={isMuted ? 'Áudio desativado (clique para ativar voz e efeitos)' : 'Áudio e Voz ativados'}
              >
                <span className="text-xl">{isMuted ? '🔇' : '🔊'}</span>
                <span className="text-[10px] sm:text-[11px] whitespace-nowrap">{isMuted ? 'Mudo' : 'Som/Voz'}</span>
              </button>

              {/* PAINEL ADMIN: EXCLUSIVO DA PROPRIETÁRIA ISA (Nenhum jogador comum visualiza este botão) */}
              {player.role === 'isa_owner' && (
                <button
                  onClick={() => {
                    soundManager.playPop();
                    onOpenAdmin();
                  }}
                  className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-950 font-black text-xs transition cursor-pointer min-w-12 border-2 border-purple-400 animate-pulse shrink-0"
                  title="Painel Exclusivo da ISA (Proprietária Oficial)"
                >
                  <span className="text-xl">👑</span>
                  <span className="text-[10px] sm:text-[11px] whitespace-nowrap">Admin</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Right: Big Action Button on Mobile */}
        <div className="pointer-events-auto pb-1">
          <button
            onClick={() => {
              soundManager.playPop();
              onInteract();
            }}
            className="w-18 h-18 sm:w-20 sm:h-20 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-400 active:scale-95 text-amber-950 font-black shadow-2xl border-4 border-white flex flex-col items-center justify-center transition cursor-pointer"
          >
            <span className="text-2xl">{interactionTarget ? interactionTarget.icon : '🌾'}</span>
            <span className="text-[10px] font-extrabold uppercase mt-0.5">Ação</span>
          </button>
        </div>
      </div>
    </div>
  );
};
