import React, { useEffect, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { AVATAR_CATALOG } from '../types/game';
import { getSupabaseAuthRedirectUrl, isSupabaseConfigured, supabase } from '../services/supabase';

interface SupabaseAccountAccessProps {
  nickname: string;
  avatarId: string;
  onAuthenticated: (identity: { id: string; nickname: string; avatar: string }) => void | Promise<void>;
}

function sanitizeNickname(value: string) {
  return value.replace(/[^\p{L}\s]/gu, ' ').replace(/\s+/g, ' ').trim().slice(0, 18);
}

function formatAuthError(error: unknown) {
  const authError = error && typeof error === 'object' ? error as { code?: string; status?: number } : {};
  if (authError.code === 'email_not_confirmed') return 'Confirme seu e-mail pelo link enviado antes de entrar.';
  if (authError.code === 'weak_password') return 'Escolha uma senha mais forte e tente novamente.';
  if (authError.status === 429 || authError.code?.includes('rate_limit')) return 'Muitas tentativas. Aguarde um pouco antes de tentar de novo.';
  if (authError.code === 'invalid_credentials' || authError.code === 'user_already_exists' || authError.code === 'email_exists') {
    return 'Não foi possível autenticar com esses dados.';
  }
  return 'Não foi possível concluir a autenticação. Tente novamente.';
}

function isKnownAvatar(value: unknown): value is string {
  return typeof value === 'string' && AVATAR_CATALOG.some((avatar) => avatar.id === value);
}

export const SupabaseAccountAccess: React.FC<SupabaseAccountAccessProps> = ({ nickname, avatarId, onAuthenticated }) => {
  const [mode, setMode] = useState<'login' | 'signup'>('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [session, setSession] = useState<Session | null>(null);
  const [isCheckingSession, setIsCheckingSession] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [statusMessage, setStatusMessage] = useState('');

  useEffect(() => {
    const authClient = supabase;
    if (!authClient) {
      setIsCheckingSession(false);
      setErrorMessage('A autenticação Supabase não está configurada neste ambiente.');
      return;
    }

    let active = true;
    const applySession = (nextSession: Session | null) => {
      if (active) setSession(nextSession);
    };
    const { data: { subscription } } = authClient.auth.onAuthStateChange((_event, nextSession) => {
      applySession(nextSession);
    });

    const restoreSession = async () => {
      try {
        const callbackUrl = new URL(window.location.href);
        const code = callbackUrl.searchParams.get('code');
        if (callbackUrl.pathname === '/auth/callback' && code) {
          const { data, error } = await authClient.auth.exchangeCodeForSession(code);
          callbackUrl.searchParams.delete('code');
          window.history.replaceState({}, document.title, `${callbackUrl.pathname}${callbackUrl.search}${callbackUrl.hash}`);
          if (!active) return;
          if (error) {
            setErrorMessage(formatAuthError(error));
            setIsCheckingSession(false);
            return;
          }
          if (data.session) {
            applySession(data.session);
            setStatusMessage('E-mail confirmado. Você já pode continuar para a fazendinha.');
          }
        }

        const { data, error } = await authClient.auth.getSession();
        if (!active) return;
        if (error) setErrorMessage('Não foi possível restaurar a sessão. Entre novamente.');
        applySession(data.session);
        setIsCheckingSession(false);
      } catch {
        if (!active) return;
        setErrorMessage('Não foi possível recuperar a sessão. Verifique a conexão e tente novamente.');
        setIsCheckingSession(false);
      }
    };

    void restoreSession();
    return () => {
      active = false;
      subscription.unsubscribe();
    };
  }, []);

  const finishAuthentication = async (authenticatedSession: Session, fallbackNickname: string, fallbackAvatar: string) => {
    if (!supabase) return;
    const metadata = authenticatedSession.user.user_metadata ?? {};
    const storedNickname = typeof metadata.nickname === 'string' ? sanitizeNickname(metadata.nickname) : '';
    const finalNickname = storedNickname || sanitizeNickname(fallbackNickname);
    const storedAvatar = isKnownAvatar(metadata.avatar_id) ? metadata.avatar_id : null;
    const finalAvatar = storedAvatar || (isKnownAvatar(fallbackAvatar) ? fallbackAvatar : AVATAR_CATALOG[0].id);

    if (finalNickname.length < 2) {
      setErrorMessage('Escolha um apelido com pelo menos duas letras.');
      return;
    }

    if (metadata.nickname !== finalNickname || metadata.avatar_id !== finalAvatar) {
      const { error } = await supabase.auth.updateUser({ data: { nickname: finalNickname, avatar_id: finalAvatar } });
      if (error) {
        setErrorMessage('A sessão foi validada, mas não foi possível salvar o perfil. Tente novamente.');
        return;
      }
    }

    setSession(authenticatedSession);
    setErrorMessage('');
    try {
      await onAuthenticated({ id: authenticatedSession.user.id, nickname: finalNickname, avatar: finalAvatar });
    } catch {
      setErrorMessage('A conta foi autenticada, mas não foi possível carregar os dados salvos da fazenda. Tente novamente.');
    }
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrorMessage('');
    setStatusMessage('');

    if (!supabase || !isSupabaseConfigured) {
      setErrorMessage('A autenticação Supabase não está configurada neste ambiente.');
      return;
    }

    const normalizedEmail = email.trim().toLowerCase();
    const safeNickname = sanitizeNickname(nickname);
    if (!normalizedEmail || !password) {
      setErrorMessage('Informe seu e-mail e sua senha para continuar.');
      return;
    }
    if (mode === 'signup' && safeNickname.length < 2) {
      setErrorMessage('Escolha um apelido com pelo menos duas letras.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (mode === 'signup') {
        const { data, error } = await supabase.auth.signUp({
          email: normalizedEmail,
          password,
          options: {
            emailRedirectTo: getSupabaseAuthRedirectUrl(),
            data: { nickname: safeNickname, avatar_id: avatarId },
          },
        });
        if (error) {
          setErrorMessage(formatAuthError(error));
          return;
        }
        if (data.session) {
          await finishAuthentication(data.session, safeNickname, avatarId);
        } else {
          setStatusMessage('Conta criada. Confirme o e-mail pelo link enviado para ativá-la. Seu e-mail não será exibido aos outros jogadores.');
        }
        return;
      }

      const { data, error } = await supabase.auth.signInWithPassword({ email: normalizedEmail, password });
      if (error) {
        setErrorMessage(formatAuthError(error));
        return;
      }
      if (!data.session) {
        setErrorMessage('A autenticação não retornou uma sessão válida.');
        return;
      }
      await finishAuthentication(data.session, safeNickname, avatarId);
    } catch {
      setErrorMessage('Erro de conexão ao autenticar. Verifique sua conexão e tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleContinue = async () => {
    if (!supabase || !session) return;
    setErrorMessage('');
    setIsSubmitting(true);
    try {
      const { data, error } = await supabase.auth.getSession();
      if (error || !data.session) {
        setSession(null);
        setErrorMessage('Sua sessão expirou. Entre novamente para continuar.');
        return;
      }
      await finishAuthentication(data.session, nickname, avatarId);
    } catch {
      setErrorMessage('Não foi possível restaurar a sessão. Entre novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSignOut = async () => {
    if (!supabase) return;
    setErrorMessage('');
    const { error } = await supabase.auth.signOut();
    if (error) {
      setErrorMessage('Não foi possível encerrar a sessão. Tente novamente.');
      return;
    }
    setSession(null);
    setStatusMessage('Sessão encerrada. Você pode entrar com outra conta.');
  };

  const handleCompositionKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter' && (event.nativeEvent.isComposing || event.keyCode === 229)) event.preventDefault();
  };

  const sessionNickname = session?.user.user_metadata?.nickname;

  return (
    <section className="mt-4 rounded-2xl border-2 border-emerald-300 bg-emerald-50 p-3 sm:p-4" aria-label="Acesso de fazendeiro">
      <div className="mb-3 flex gap-2" role="group" aria-label="Tipo de acesso">
        <button
          type="button"
          onClick={() => { setMode('signup'); setErrorMessage(''); setStatusMessage(''); }}
          aria-pressed={mode === 'signup'}
          className={`flex-1 rounded-xl px-3 py-2 text-xs font-black transition ${mode === 'signup' ? 'bg-emerald-600 text-white shadow' : 'bg-white text-emerald-900 hover:bg-emerald-100'}`}
        >
          Criar conta
        </button>
        <button
          type="button"
          onClick={() => { setMode('login'); setErrorMessage(''); setStatusMessage(''); }}
          aria-pressed={mode === 'login'}
          className={`flex-1 rounded-xl px-3 py-2 text-xs font-black transition ${mode === 'login' ? 'bg-emerald-600 text-white shadow' : 'bg-white text-emerald-900 hover:bg-emerald-100'}`}
        >
          Entrar
        </button>
      </div>

      <p className="mb-3 text-[11px] font-semibold text-emerald-900">
        O e-mail é usado apenas para autenticação e não aparece para os outros jogadores.
      </p>

      {session && (
        <div className="mb-3 flex flex-col gap-2 rounded-xl border border-emerald-200 bg-white p-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs font-bold text-emerald-950" aria-live="polite">
            Sessão ativa{typeof sessionNickname === 'string' ? `: ${sanitizeNickname(sessionNickname)}` : ''}.
          </p>
          <div className="flex gap-2">
            <button type="button" onClick={handleContinue} disabled={isSubmitting || isCheckingSession} className="rounded-lg bg-emerald-600 px-3 py-2 text-xs font-black text-white disabled:opacity-50">
              Continuar
            </button>
            <button type="button" onClick={handleSignOut} disabled={isSubmitting} className="rounded-lg bg-amber-100 px-3 py-2 text-xs font-black text-amber-950 disabled:opacity-50">
              Trocar conta
            </button>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-2.5">
        <div>
          <label htmlFor="farmer-email" className="mb-1 block text-xs font-black text-emerald-950">E-mail da conta</label>
          <input
            id="farmer-email"
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            onKeyDown={handleCompositionKeyDown}
            autoComplete="email"
            required
            maxLength={254}
            className="w-full rounded-xl border-2 border-emerald-200 bg-white px-3 py-2 text-sm font-semibold text-emerald-950 outline-none focus:border-emerald-500"
          />
        </div>
        <div>
          <label htmlFor="farmer-password" className="mb-1 block text-xs font-black text-emerald-950">Senha</label>
          <input
            id="farmer-password"
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            onKeyDown={handleCompositionKeyDown}
            autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
            required
            minLength={8}
            maxLength={128}
            className="w-full rounded-xl border-2 border-emerald-200 bg-white px-3 py-2 text-sm font-semibold text-emerald-950 outline-none focus:border-emerald-500"
          />
        </div>
        {errorMessage && <p className="rounded-lg bg-red-50 px-3 py-2 text-xs font-bold text-red-800" role="alert">{errorMessage}</p>}
        {statusMessage && <p className="rounded-lg bg-white px-3 py-2 text-xs font-bold text-emerald-900" role="status">{statusMessage}</p>}
        {!isSupabaseConfigured && <p className="text-xs font-bold text-red-800" role="alert">Supabase indisponível: a configuração pública não foi encontrada.</p>}
        {isCheckingSession && <p className="text-xs font-semibold text-emerald-800" role="status">Verificando sessão salva…</p>}
        <button
          type="submit"
          disabled={!isSupabaseConfigured || isSubmitting || isCheckingSession}
          className="w-full rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 px-4 py-3 text-sm font-black text-white shadow-md transition hover:from-emerald-600 hover:to-green-700 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {isSubmitting ? 'Autenticando…' : mode === 'signup' ? 'Criar conta e entrar' : 'Entrar na fazendinha'}
        </button>
      </form>
    </section>
  );
};
