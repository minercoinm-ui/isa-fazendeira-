import React from 'react';
import { CROPS_CATALOG, CropType } from '../types/game';
import { soundManager } from '../audio/soundManager';

interface ShopModalProps {
  isOpen: boolean;
  onClose: () => void;
  playerCoins: number;
  seedCosts: Partial<Record<CropType, number>>;
  onBuySeed: (cropType: CropType, cost: number) => void;
  onBuyFeed: () => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({
  isOpen,
  onClose,
  playerCoins,
  seedCosts,
  onBuySeed,
  onBuyFeed,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 pointer-events-auto">
      <div className="bg-white border-4 border-amber-400 rounded-3xl max-w-xl w-full p-5 sm:p-6 shadow-2xl relative">
        <button
          onClick={() => {
            soundManager.playPop();
            onClose();
          }}
          className="absolute top-4 right-4 bg-amber-100 hover:bg-amber-200 text-amber-900 font-black rounded-full w-9 h-9 flex items-center justify-center border-2 border-amber-400 cursor-pointer"
        >
          ✕
        </button>

        <div className="flex items-center justify-between mb-4 border-b border-amber-200 pb-3">
          <h3 className="text-2xl font-black text-amber-950 flex items-center gap-2">
            <span>🏪</span> Armazém & Loja da Fazenda
          </h3>

          <div className="bg-amber-100 border-2 border-amber-300 px-3 py-1 rounded-full text-amber-950 font-black text-sm">
            Saldo: {playerCoins} 🪙
          </div>
        </div>

        <div className="space-y-3 max-h-[55vh] overflow-y-auto pr-1">
          <h4 className="text-xs font-black uppercase tracking-wider text-amber-800">
            Sementes Frescas para Plantio:
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {Object.values(CROPS_CATALOG).map((crop) => {
              const seedCost = seedCosts[crop.id];
              const canAfford = typeof seedCost === 'number' && Number.isSafeInteger(seedCost) && playerCoins >= seedCost;
              return (
                <div
                  key={crop.id}
                  className="bg-amber-50/70 border-2 border-amber-200 rounded-2xl p-3.5 flex flex-col justify-between"
                >
                  <div className="flex items-start gap-3">
                    <span className="text-3xl shrink-0">{crop.icon}</span>
                    <div>
                      <h5 className="font-black text-sm text-amber-950">{crop.name}</h5>
                      <p className="text-xs text-amber-800">{crop.description}</p>
                      <div className="mt-1 flex items-center gap-2 text-[11px] text-amber-700 font-bold">
                        <span>⏱️ {crop.growthTime}s</span>
                        <span>•</span>
                        <span>⭐ +{crop.xpReward} XP</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      if (canAfford && typeof seedCost === 'number') {
                        onBuySeed(crop.id, seedCost);
                      }
                    }}
                    disabled={!canAfford}
                    className={`mt-3 w-full py-2 rounded-xl text-xs font-black transition cursor-pointer flex items-center justify-center gap-1.5 ${
                      canAfford
                        ? 'bg-amber-500 hover:bg-amber-600 text-white shadow'
                        : 'bg-gray-200 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    <span>Comprar 1x Semente</span>
                    <span>({typeof seedCost === 'number' ? `${seedCost} 🪙` : 'Indisponível'})</span>
                  </button>
                </div>
              );
            })}
          </div>

          <h4 className="text-xs font-black uppercase tracking-wider text-amber-800 pt-3">
            Cuidados com os Animais:
          </h4>

          <div className="bg-amber-50/70 border-2 border-amber-200 rounded-2xl p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-3xl">🌾</span>
              <div>
                <h5 className="font-black text-sm text-amber-950">Saco de Feno & Ração Especial</h5>
                <p className="text-xs text-amber-800">Alimente vacas, galinhas e porquinhos para produzir leite e ovos.</p>
              </div>
            </div>

            <button
              onClick={() => {
                if (playerCoins >= 15) onBuyFeed();
              }}
              disabled={playerCoins < 15}
              className={`py-2 px-3 rounded-xl text-xs font-black transition cursor-pointer shrink-0 ${
                playerCoins >= 15
                  ? 'bg-amber-500 hover:bg-amber-600 text-white shadow'
                  : 'bg-gray-200 text-gray-500 cursor-not-allowed'
              }`}
            >
              Comprar (15 🪙)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
