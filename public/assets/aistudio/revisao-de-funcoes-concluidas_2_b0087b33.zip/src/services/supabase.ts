import { createClient, SupabaseClient } from '@supabase/supabase-js';

const publicEnv = import.meta.env as unknown as Record<string, string | undefined>;
const supabaseUrl = publicEnv.VITE_SUPABASE_URL || publicEnv.NEXT_PUBLIC_SUPABASE_URL;
const supabaseAnonKey =
  publicEnv.VITE_SUPABASE_ANON_KEY ||
  publicEnv.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  publicEnv.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

export const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey);

export const supabase: SupabaseClient | null = isSupabaseConfigured
  ? createClient(supabaseUrl!, supabaseAnonKey!, {
      auth: {
        autoRefreshToken: true,
        detectSessionInUrl: false,
        flowType: 'pkce',
        persistSession: true,
      },
    })
  : null;

export function getSupabaseAuthRedirectUrl() {
  const redirectUrl = publicEnv.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL;
  return redirectUrl || `${window.location.origin}/auth/callback`;
}

export async function logGameEvent(eventType: string, details: Record<string, any>, nickname?: string) {
  if (!supabase) return;
  try {
    await supabase.from('game_events').insert({
      event_type: eventType,
      details,
      player_nickname: nickname || 'Fazendeiro Visitante',
    });
  } catch (e) {
    console.warn('Supabase event log error:', e);
  }
}
