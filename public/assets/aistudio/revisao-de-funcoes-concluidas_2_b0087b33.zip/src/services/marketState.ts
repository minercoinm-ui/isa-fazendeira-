import {
  CROPS_CATALOG,
  FarmLand,
  FarmPlot,
  InventoryItem,
  MARKET_PRODUCT_INFO,
  MarketListing,
  ProductId,
} from '../types/game';
import type { SupabaseClient } from '@supabase/supabase-js';
import { supabase } from './supabase';

export interface MarketStateProduct {
  product_id: string;
  name: string;
  category: string;
  icon: string;
  description?: string;
  min_price?: number;
  recommended_price?: number;
  max_price?: number;
  growth_seconds?: number;
  seed_cost?: number;
  [key: string]: unknown;
}

export interface MarketStateSnapshot {
  player: { id: string; nickname: string; avatar_id: string };
  wallet: { coins: number };
  inventory: Array<{ item_id: string; quantity: number }>;
  stall: { id: string; owner_id: string; stall_name: string } | null;
  products: MarketStateProduct[];
  listings: Array<{
    id: string;
    stall_id: string;
    seller_id: string;
    seller_name: string;
    stall_name: string;
    product_id: string;
    product_name: string;
    icon: string;
    category: string;
    quantity: number;
    price_per_unit: number;
    sold_count: number;
    updated_at: string;
  }>;
  transactions: Array<Record<string, unknown>>;
  farm_plots: Array<{
    id: number;
    cropType: string | null;
    stage: number;
    watered: boolean;
    plantedAt: string | null;
    growthTime: number;
    ownerId: string | null;
  }>;
  lands: Array<{ id: string; name: string; price: number; owner_id: string | null }>;
  owned_land_ids: string[];
  npc_budget_remaining: number | null;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parseMarketState(value: unknown): MarketStateSnapshot {
  if (!isRecord(value) || !isRecord(value.player) || !isRecord(value.wallet)) {
    throw new Error('O banco retornou um estado de fazenda incompleto.');
  }

  const playerId = value.player.id;
  const nickname = value.player.nickname;
  const avatarId = value.player.avatar_id;
  const coins = Number(value.wallet.coins);
  const requiredArrays = ['inventory', 'products', 'listings', 'transactions', 'farm_plots', 'lands', 'owned_land_ids'];

  if (typeof playerId !== 'string' || typeof nickname !== 'string' || typeof avatarId !== 'string' || !Number.isSafeInteger(coins) || coins < 0) {
    throw new Error('O perfil ou a carteira retornados pelo banco são inválidos.');
  }
  if (requiredArrays.some((key) => !Array.isArray(value[key]))) {
    throw new Error('O banco retornou coleções incompletas para o jogador.');
  }

  return value as unknown as MarketStateSnapshot;
}

export type MarketFarmAction = 'plant' | 'water' | 'harvest';

export interface MarketBuyResult {
  state: MarketStateSnapshot;
  duplicate: boolean;
}

const knownMarketErrors = [
  'Autenticação necessária',
  'Moedas insuficientes',
  'Quantidade inválida',
  'Barraca não encontrada',
  'Não pode comprar da própria barraca',
  'Estoque insuficiente',
  'Semente indisponível',
  'Você não possui essa semente',
  'Talhão inválido',
  'Talhão não encontrado',
  'Talhão ocupado',
  'Não é possível regar este talhão',
  'Talhão vazio',
  'Plantação ainda não amadureceu',
  'Ação agrícola inválida',
  'Produto indisponível para venda',
  'Preço fora da faixa permitida',
  'Você não possui quantidade suficiente',
];

function marketOperationError(error: unknown): Error {
  const rawMessage = isRecord(error) && typeof error.message === 'string' ? error.message : '';
  const knownMessage = knownMarketErrors.find((message) => rawMessage.includes(message));
  return new Error(knownMessage || 'Não foi possível confirmar a operação no Supabase. O estado anterior foi preservado.');
}

async function getAuthenticatedClient(expectedPlayerId: string): Promise<SupabaseClient> {
  if (!supabase) throw new Error('A conexão Supabase não está configurada.');
  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) throw new Error('Sua sessão expirou. Entre novamente para continuar.');
  if (data.user.id !== expectedPlayerId) throw new Error('A sessão autenticada não corresponde ao jogador. Entre novamente.');
  return supabase;
}

async function callStateRpc(
  client: SupabaseClient,
  functionName: string,
  args?: Record<string, unknown>
): Promise<MarketStateSnapshot> {
  const { data, error } = await client.rpc(functionName, args);
  if (error) throw marketOperationError(error);
  return parseMarketState(data);
}

export async function ensureAndLoadMarketState(expectedPlayerId: string): Promise<MarketStateSnapshot> {
  const client = await getAuthenticatedClient(expectedPlayerId);
  const { error: ensureError } = await client.rpc('market_ensure_player');
  if (ensureError) throw marketOperationError(ensureError);

  const state = await callStateRpc(client, 'market_state');
  if (state.player.id !== expectedPlayerId) throw new Error('O estado carregado pertence a outra conta.');
  return state;
}

export async function performMarketFarmAction(
  playerId: string,
  plotId: number,
  action: MarketFarmAction,
  cropType?: string
): Promise<MarketStateSnapshot> {
  if (!Number.isSafeInteger(plotId) || plotId < 0 || plotId > 7) throw new Error('Talhão inválido.');
  const client = await getAuthenticatedClient(playerId);
  return callStateRpc(client, 'market_farm_action', {
    p_plot_id: plotId,
    p_action: action,
    p_crop_type: cropType ?? null,
  });
}

export async function purchaseMarketSeed(playerId: string, cropType: string): Promise<MarketStateSnapshot> {
  const client = await getAuthenticatedClient(playerId);
  return callStateRpc(client, 'market_buy_seed', { p_crop_type: cropType });
}

export async function purchaseMarketFeed(playerId: string): Promise<MarketStateSnapshot> {
  const client = await getAuthenticatedClient(playerId);
  return callStateRpc(client, 'market_buy_feed');
}

export async function restockMarketProduct(
  playerId: string,
  productId: string,
  quantity: number,
  unitPrice: number
): Promise<MarketStateSnapshot> {
  if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > 1000) throw new Error('Quantidade inválida.');
  if (!Number.isSafeInteger(unitPrice) || unitPrice < 1) throw new Error('Preço fora da faixa permitida.');
  const client = await getAuthenticatedClient(playerId);
  return callStateRpc(client, 'market_restock', {
    p_product_id: productId,
    p_quantity: quantity,
    p_unit_price: unitPrice,
  });
}

export async function purchaseMarketListing(
  playerId: string,
  stallId: string,
  productId: string,
  quantity: number,
  idempotencyKey: string
): Promise<MarketBuyResult> {
  if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > 100) throw new Error('Quantidade inválida.');
  const client = await getAuthenticatedClient(playerId);
  const { data, error } = await client.rpc('market_buy', {
    p_stall_id: stallId,
    p_product_id: productId,
    p_quantity: quantity,
    p_idempotency_key: idempotencyKey,
  });
  if (error) throw marketOperationError(error);
  if (!isRecord(data) || data.success !== true || !isRecord(data.state)) {
    throw new Error('O Supabase não confirmou a compra. O estado anterior foi preservado.');
  }
  return {
    state: parseMarketState(data.state),
    duplicate: data.duplicate === true,
  };
}

export function mapInventoryFromMarketState(state: MarketStateSnapshot): Record<string, InventoryItem> {
  const productById = new Map(state.products.map((product) => [product.product_id, product]));
  const inventory: Record<string, InventoryItem> = {};

  for (const entry of state.inventory) {
    const id = entry.item_id;
    const count = Number(entry.quantity);
    if (!id || !Number.isSafeInteger(count) || count < 0) continue;

    if (id.endsWith('_seed')) {
      const cropId = id.slice(0, -5) as keyof typeof CROPS_CATALOG;
      const crop = CROPS_CATALOG[cropId];
      if (!crop) continue;
      const product = productById.get(cropId);
      inventory[id] = {
        id,
        name: `Semente de ${crop.name}`,
        category: 'seed',
        count,
        icon: product?.icon || crop.icon,
        value: Number(product?.seed_cost ?? crop.seedCost),
      };
      continue;
    }

    const product = productById.get(id);
    const localProduct = MARKET_PRODUCT_INFO[id as ProductId];
    const crop = CROPS_CATALOG[id as keyof typeof CROPS_CATALOG];
    const isFeed = id === 'feed';
    inventory[id] = {
      id,
      name: isFeed ? 'Ração' : product?.name || localProduct?.name || crop?.name || id,
      category: isFeed ? 'tool' : crop ? 'crop' : 'product',
      count,
      icon: isFeed ? '🌾' : product?.icon || localProduct?.icon || crop?.icon || '📦',
      value: isFeed ? 0 : Number(product?.recommended_price ?? localProduct?.defaultPrice ?? crop?.sellValue ?? 0),
    };
  }

  return inventory;
}

export function mapPlotsFromMarketState(state: MarketStateSnapshot): FarmPlot[] {
  return state.farm_plots.map((plot) => ({
    id: Number(plot.id),
    cropType: plot.cropType && plot.cropType in CROPS_CATALOG ? plot.cropType as keyof typeof CROPS_CATALOG : null,
    stage: Math.max(0, Math.min(3, Number(plot.stage) || 0)),
    watered: plot.watered === true,
    plantedAt: plot.plantedAt ? Date.parse(plot.plantedAt) : null,
    growthTime: Math.max(1, Number(plot.growthTime) || 25),
  }));
}

export function mapListingsFromMarketState(state: MarketStateSnapshot): MarketListing[] {
  return state.listings.map((listing) => ({
    id: listing.id,
    stallId: listing.stall_id,
    sellerId: listing.seller_id,
    sellerName: listing.seller_name,
    productId: listing.product_id as ProductId,
    productName: listing.product_name,
    icon: listing.icon,
    category: listing.category,
    quantity: Number(listing.quantity),
    pricePerUnit: Number(listing.price_per_unit),
    totalPrice: Number(listing.quantity) * Number(listing.price_per_unit),
    createdAt: Date.parse(listing.updated_at) || 0,
  }));
}

export function mapLandsFromMarketState(
  state: MarketStateSnapshot,
  mapTemplates: FarmLand[],
  playerId: string
): FarmLand[] {
  return state.lands.flatMap((land) => {
    const template = mapTemplates.find((candidate) => candidate.id === land.id);
    if (!template) return [];
    const ownerId = land.owner_id;
    const ownerName = ownerId ? (ownerId === playerId ? state.player.nickname : 'Fazendeiro') : null;
    return [{
      ...template,
      name: land.name,
      price: Number(land.price),
      ownerId,
      ownerName,
      status: ownerId ? 'owned' as const : 'available' as const,
    }];
  });
}
