/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { TitleScreen } from './components/TitleScreen';
import { HUD } from './components/HUD';
import { IsaDialogueModal } from './components/IsaDialogueModal';
import { InventoryModal } from './components/InventoryModal';
import { ShopModal } from './components/ShopModal';
import { MarketModal } from './components/MarketModal';
import { LandMarketModal } from './components/LandMarketModal';
import { IsaReactionBanner } from './components/IsaReactionBanner';
import { CommunityGoalModal } from './components/CommunityGoalModal';
import { QuickChatModal } from './components/QuickChatModal';
import { AdminModal } from './components/AdminModal';
import { AvatarCustomizerModal } from './components/AvatarCustomizerModal';
import { GameEngine, InteractionTarget } from './game/GameEngine';
import { soundManager } from './audio/soundManager';
import { isaVoiceManager } from './audio/isaVoiceManager';
import { networkManager } from './services/networkManager';
import { supabase } from './services/supabase';
import {
  ensureAndLoadMarketState,
  mapInventoryFromMarketState,
  mapLandsFromMarketState,
  mapListingsFromMarketState,
  mapPlotsFromMarketState,
  performMarketFarmAction,
  purchaseMarketFeed,
  purchaseMarketListing,
  purchaseMarketSeed,
  restockMarketProduct,
  type MarketStateSnapshot,
} from './services/marketState';
import {
  PlayerProfile,
  FarmPlot,
  FarmLand,
  MarketListing,
  ProductId,
  AVATAR_CATALOG,
  CommunityGoal,
  IsaMission,
  CropType,
  CROPS_CATALOG,
  RemotePlayer,
  IsaAnimationState,
} from './types/game';
import confetti from 'canvas-confetti';

const INITIAL_PLOTS: FarmPlot[] = [
  { id: 0, cropType: 'corn', stage: 3, watered: true, plantedAt: Date.now() - 35000, growthTime: 25 },
  { id: 1, cropType: 'corn', stage: 3, watered: true, plantedAt: Date.now() - 35000, growthTime: 25 },
  { id: 2, cropType: 'carrot', stage: 2, watered: true, plantedAt: Date.now() - 15000, growthTime: 20 },
  { id: 3, cropType: 'tomato', stage: 3, watered: true, plantedAt: Date.now() - 40000, growthTime: 30 },
  { id: 4, cropType: 'corn', stage: 1, watered: false, plantedAt: Date.now() - 5000, growthTime: 25 },
  { id: 5, cropType: null, stage: 0, watered: false, plantedAt: null, growthTime: 25 },
  { id: 6, cropType: null, stage: 0, watered: false, plantedAt: null, growthTime: 25 },
  { id: 7, cropType: null, stage: 0, watered: false, plantedAt: null, growthTime: 25 },
];

const INITIAL_MISSIONS: IsaMission[] = [
  {
    id: 'm-welcome',
    title: 'Boas-vindas da Isa',
    description: 'Aproxime-se da Isa e converse para conhecer a fazendinha!',
    isaDialogue: 'Que alegria ter você aqui na fazendinha! Plante bastante milho e cuide dos bichinhos comigo!',
    requiredAction: 'talk',
    requiredCount: 1,
    currentCount: 0,
    rewardCoins: 40,
    rewardXp: 30,
    completed: false,
    claimed: false,
  },
  {
    id: 'm-harvest-corn',
    title: 'Primeira Colheita de Milho',
    description: 'Colha 2 espigas de milho maduro na horta da Isa.',
    isaDialogue: 'O milho dourado está tão bonito e doce! Vamos colher para o celeiro!',
    requiredAction: 'harvest_corn',
    requiredCount: 2,
    currentCount: 0,
    rewardCoins: 50,
    rewardXp: 45,
    completed: false,
    claimed: false,
  },
  {
    id: 'm-plant-corn',
    title: 'Plantar Milho Fresco',
    description: 'Plante 2 sementes de milho em talhões vazios da horta.',
    isaDialogue: 'A terra está fofinha e fértil! Plante sementes de milho para nossa fazenda crescer.',
    requiredAction: 'plant_corn',
    requiredCount: 2,
    currentCount: 0,
    rewardCoins: 45,
    rewardXp: 40,
    completed: false,
    claimed: false,
  },
  {
    id: 'm-feed-animal',
    title: 'Alimentar os Bichinhos',
    description: 'Visite a Mimosa (vaca) ou as galinhas para alimentar ou ordenhar.',
    isaDialogue: 'Os animais ficam tão felizes quando recebem carinho e comida fresquinha!',
    requiredAction: 'feed_animal',
    requiredCount: 1,
    currentCount: 0,
    rewardCoins: 60,
    rewardXp: 50,
    completed: false,
    claimed: false,
  },
];

const INITIAL_LANDS: FarmLand[] = [
  {
    id: 'land-lake',
    name: 'Lago Encantado',
    description: 'Terreno com vista panorâmica para o lago e brisa refrescante.',
    areaM2: 300,
    price: 150,
    status: 'available',
    ownerId: null,
    ownerName: null,
    x: -28,
    z: -25,
    width: 14,
    depth: 14,
    color: '#0284c7',
    constructions: [],
  },
  {
    id: 'land-orchard',
    name: 'Colina das Macieiras',
    description: 'Solo rico e ensolarado, perfeito para plantações floridas.',
    areaM2: 450,
    price: 220,
    status: 'available',
    ownerId: null,
    ownerName: null,
    x: 28,
    z: -25,
    width: 15,
    depth: 15,
    color: '#16a34a',
    constructions: [],
  },
  {
    id: 'land-meadow',
    name: 'Pasto dos Sonhos',
    description: 'Grande espaço verde e plano, ideal para criar animais.',
    areaM2: 600,
    price: 300,
    status: 'available',
    ownerId: null,
    ownerName: null,
    x: 28,
    z: 25,
    width: 16,
    depth: 16,
    color: '#d97706',
    constructions: [],
  },
  {
    id: 'land-harvest',
    name: 'Grande Safra Fértil',
    description: 'Área nobre super fértil para quem quer ser um grande produtor rural.',
    areaM2: 800,
    price: 400,
    status: 'available',
    ownerId: null,
    ownerName: null,
    x: -28,
    z: 25,
    width: 18,
    depth: 18,
    color: '#9333ea',
    constructions: [],
  },
  {
    id: 'land-belavista',
    name: 'Mirante Bela Vista',
    description: 'Terreno mais alto da fazenda com visão completa de toda a propriedade!',
    areaM2: 500,
    price: 280,
    status: 'available',
    ownerId: null,
    ownerName: null,
    x: 0,
    z: 38,
    width: 15,
    depth: 15,
    color: '#ea580c',
    constructions: [],
  },
];

export default function App() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [floatingAlert, setFloatingAlert] = useState<string | null>(null);

  // A sessão Supabase é persistida pelo cliente Auth; o perfil local não é usado como identidade.
  const [player, setPlayer] = useState<PlayerProfile>({
    id: 'pending-auth',
    nickname: 'Amiguinho',
    avatar: 'leo',
    role: 'visitor',
    level: 1,
    xp: 0,
    nextLevelXp: 80,
    coins: 0,
    inventory: {},
    ownedLandIds: [],
  });

  const [selectedSeed, setSelectedSeed] = useState<CropType>('corn');
  const [plots, setPlots] = useState<FarmPlot[]>(INITIAL_PLOTS);
  const [missions, setMissions] = useState<IsaMission[]>(INITIAL_MISSIONS);
  const [communityGoal, setCommunityGoal] = useState<CommunityGoal>({
    id: 'goal-1',
    title: 'Grande Colheita de Milho Coletiva',
    target: 100,
    current: 34,
    rewardCoins: 250,
    rewardXp: 180,
    completed: false,
  });
  const [communityClaimed] = useState(false);

  // Market & Land State
  const [marketState, setMarketState] = useState<MarketStateSnapshot | null>(null);
  const [marketListings, setMarketListings] = useState<MarketListing[]>([]);
  const [lands, setLands] = useState<FarmLand[]>(INITIAL_LANDS);

  // Isa Voice & Subtitles State
  const [isaSubtitles, setIsaSubtitles] = useState<{ text: string; animation: IsaAnimationState } | null>(null);

  // Multiplayer State
  const [playersOnlineCount, setPlayersOnlineCount] = useState<number>(0);
  const [onlinePlayerNames, setOnlinePlayerNames] = useState<string[]>([]);
  const remotePlayersRef = useRef<Map<string, RemotePlayer>>(new Map());

  // Interaction State
  const [currentTarget, setCurrentTarget] = useState<InteractionTarget | null>(null);

  // Modals
  const [isIsaModalOpen, setIsIsaModalOpen] = useState(false);
  const [isInventoryOpen, setIsInventoryOpen] = useState(false);
  const [isShopOpen, setIsShopOpen] = useState(false);
  const [isMarketOpen, setIsMarketOpen] = useState(false);
  const [isLandMarketOpen, setIsLandMarketOpen] = useState(false);
  const [isCommunityGoalOpen, setIsCommunityGoalOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAvatarCustomizerOpen, setIsAvatarCustomizerOpen] = useState(false);

  // References
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const lastMoveBroadcastRef = useRef<number>(0);
  const lastActivityTimeRef = useRef<number>(Date.now());
  const pendingEconomyActionsRef = useRef(new Set<string>());
  const marketBuyIdempotencyKeysRef = useRef(new Map<string, string>());

  const showAlert = (msg: string) => {
    setFloatingAlert(msg);
    setTimeout(() => {
      setFloatingAlert((curr) => (curr === msg ? null : curr));
    }, 3500);
  };

  const applyMarketState = (
    state: MarketStateSnapshot,
    options?: { role?: PlayerProfile['role']; avatarFallback?: string }
  ) => {
    setMarketState(state);
    setPlayer((prev) => ({
      ...prev,
      id: state.player.id,
      nickname: state.player.nickname,
      avatar: state.player.avatar_id || options?.avatarFallback || prev.avatar,
      role: options?.role ?? prev.role,
      coins: Number(state.wallet.coins),
      inventory: mapInventoryFromMarketState(state),
      ownedLandIds: state.owned_land_ids,
    }));
    const confirmedPlots = mapPlotsFromMarketState(state);
    const confirmedLands = mapLandsFromMarketState(state, INITIAL_LANDS, state.player.id);
    setPlots(confirmedPlots);
    setMarketListings(mapListingsFromMarketState(state));
    setLands(confirmedLands);
    engineRef.current?.updatePlotMeshes(confirmedPlots);
    engineRef.current?.updateLands(confirmedLands, state.player.id);
  };

  const runMarketStateAction = async (
    key: string,
    operation: () => Promise<MarketStateSnapshot>
  ): Promise<MarketStateSnapshot | null> => {
    if (pendingEconomyActionsRef.current.has(key)) return null;
    pendingEconomyActionsRef.current.add(key);
    try {
      const state = await operation();
      applyMarketState(state);
      return state;
    } catch (error) {
      showAlert(error instanceof Error ? error.message : 'Não foi possível confirmar no Supabase.');
      return null;
    } finally {
      pendingEconomyActionsRef.current.delete(key);
    }
  };

  // Subscribe to Isa Voice Subtitles & 3D Model Animations
  useEffect(() => {
    const unsub = isaVoiceManager.subscribeSubtitles((speech) => {
      setIsaSubtitles(speech);
      if (engineRef.current) {
        engineRef.current.setIsaAnimationState(speech?.animation || 'idle');
      }
    });
    return unsub;
  }, []);

  // Periodic Inactivity Isa Reaction (after 60s idle)
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      const now = Date.now();
      if (now - lastActivityTimeRef.current > 75000 && !isaSubtitles) {
        lastActivityTimeRef.current = now;
        isaVoiceManager.speak(
          'Vamos lá? Ainda temos muito trabalho pela frente na nossa fazendinha!',
          'idle'
        );
      }
    }, 15000);

    return () => clearInterval(interval);
  }, [isPlaying, isaSubtitles]);

  // Só inicia a cena depois que o perfil e o estado econômico vierem do Supabase.
  const handleStartGame = async (_nickname: string, avatar: string, role: 'visitor' | 'isa_owner' = 'visitor', playerId?: string) => {
    if (!supabase || !playerId) throw new Error('Entre com uma conta Supabase para carregar a fazenda.');

    const { data: authData, error: authError } = await supabase.auth.getUser();
    if (authError || !authData.user || authData.user.id !== playerId) {
      throw new Error('A sessão autenticada não corresponde ao jogador. Entre novamente.');
    }

    const state = await ensureAndLoadMarketState(authData.user.id);
    if (state.player.id !== authData.user.id) {
      throw new Error('O estado carregado pertence a outra conta.');
    }

    applyMarketState(state, { role, avatarFallback: avatar });
    setIsPlaying(true);
    lastActivityTimeRef.current = Date.now();

    setTimeout(() => {
      if (role === 'isa_owner') {
        isaVoiceManager.speak(
          'Bem-vinda, Isa! Sua fazendinha está linda e pronta para as atividades!',
          'cheering'
        );
      } else {
        isaVoiceManager.speak(
          'Obaaa! Temos visita! Seja muito bem-vindo à Fazendinha da Isa!',
          'waving'
        );
      }
    }, 1200);
  };

  // Initialize GameEngine & Network after Start Game
  useEffect(() => {
    if (!isPlaying || !canvasMountRef.current) return;

    // 1. Create Engine
    const engine = new GameEngine(
      canvasMountRef.current,
      player.avatar,
      player.nickname,
      player.level
    );
    engineRef.current = engine;

    engine.onInteractionChange = (target) => {
      setCurrentTarget(target);
    };

    engine.onPlayerMove = (x, y, z, rotation, isMoving) => {
      lastActivityTimeRef.current = Date.now();
      const now = Date.now();
      if (now - lastMoveBroadcastRef.current > 60) {
        lastMoveBroadcastRef.current = now;
        networkManager.sendMovement(x, y, z, rotation, isMoving);
      }
    };

    // Render initial plots and lands
    engine.updatePlotMeshes(plots);
    engine.updateLands(lands, player.id);

    // 2. Connect to Multiplayer Network
    networkManager.connect(player.id, {
      nickname: player.nickname,
      avatar: player.avatar,
      role: player.role,
      color: '#f59e0b',
      x: engine.playerPos.x,
      y: engine.playerPos.y,
      z: engine.playerPos.z,
      rotation: engine.playerRotation,
    }, async () => {
      if (!supabase) return null;
      const { data, error } = await supabase.auth.getSession();
      return error ? null : data.session?.access_token ?? null;
    });

    // 3. Subscribe to Network Events
    const unsubscribe = networkManager.subscribe((msg) => {
      if (msg.type === 'auth_error') {
        showAlert('Sua sessão não pôde ser validada. Recarregue e entre novamente para conectar.');
        remotePlayersRef.current.clear();
        setOnlinePlayerNames([]);
        setPlayersOnlineCount(1);
      } else if (msg.type === 'welcome') {
        if (msg.communityGoal) {
          setCommunityGoal(msg.communityGoal);
        }
        if (msg.players && Array.isArray(msg.players)) {
          msg.players.forEach((p: RemotePlayer) => {
            if (p.id !== player.id) {
              remotePlayersRef.current.set(p.id, p);
              engine.updateRemotePlayer(p);
            }
          });
          updatePlayersOnlineList();
        }
      } else if (msg.type === 'player_joined') {
        if (msg.player && msg.player.id !== player.id) {
          remotePlayersRef.current.set(msg.player.id, msg.player);
          engine.updateRemotePlayer(msg.player);
          updatePlayersOnlineList();
          showAlert(`🌾 ${msg.player.nickname} entrou na fazendinha!`);
        }
      } else if (msg.type === 'player_moved') {
        if (msg.id !== player.id) {
          engine.updateRemotePlayer(msg);
        }
      } else if (msg.type === 'player_left') {
        remotePlayersRef.current.delete(msg.id);
        engine.removeRemotePlayer(msg.id);
        updatePlayersOnlineList();
      } else if (msg.type === 'player_chat') {
        if (msg.id !== player.id) {
          const remote = remotePlayersRef.current.get(msg.id);
          if (remote) {
            remote.message = { text: msg.text, time: msg.time || Date.now() };
            engine.updateRemotePlayer(remote);
          }
          showAlert(`💬 ${msg.nickname}: "${msg.text}"`);
        }
      } else if (msg.type === 'community_goal_updated') {
        setCommunityGoal(msg.goal);
        if (msg.goal.completed && !communityGoal.completed) {
          isaVoiceManager.speak(
            'Conseguimos! Glória a Deus! Quando trabalhamos juntos, nossa fazenda fica ainda mais bonita!',
            'dancing'
          );
        }
      } else if (msg.type === 'magic_rain') {
        soundManager.playWater();
        showAlert('🌧️ Chuva Mágica! Todas as plantações foram regadas!');
        setPlots((prev) => {
          const next = prev.map((p) => ({ ...p, watered: true }));
          engine.updatePlotMeshes(next);
          return next;
        });
      }
    });

    function updatePlayersOnlineList() {
      const names = Array.from(remotePlayersRef.current.values()).map((p) => p.nickname);
      setOnlinePlayerNames(names);
      setPlayersOnlineCount(names.length + 1); // +1 is self
    }

    return () => {
      unsubscribe();
      networkManager.disconnect();
      engine.dispose();
      engineRef.current = null;
    };
  }, [isPlaying]);

  // Periodic Crop Growth Simulation
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      const now = Date.now();
      let changed = false;

      setPlots((prev) => {
        const next = prev.map((plot) => {
          if (!plot.cropType || !plot.plantedAt || plot.stage >= 3) return plot;

          const elapsedSec = (now - plot.plantedAt) / 1000;
          const targetTime = plot.watered ? plot.growthTime * 0.7 : plot.growthTime;

          let newStage = plot.stage;
          if (elapsedSec >= targetTime) {
            newStage = 3; // Ripe
          } else if (elapsedSec >= targetTime * 0.45) {
            newStage = 2; // Growing
          } else {
            newStage = 1; // Sprout
          }

          if (newStage !== plot.stage) {
            changed = true;
            return { ...plot, stage: newStage };
          }
          return plot;
        });

        if (changed && engineRef.current) {
          engineRef.current.updatePlotMeshes(next);
        }
        return next;
      });
    }, 3000);

    return () => clearInterval(interval);
  }, [isPlaying]);

  // Handle XP and Level Progression
  const addXp = (xpGain: number) => {
    setPlayer((prev) => {
      let newXp = prev.xp + xpGain;
      let newLevel = prev.level;
      let nextTarget = prev.nextLevelXp;

      if (newXp >= nextTarget) {
        newLevel += 1;
        newXp = newXp - nextTarget;
        nextTarget = Math.round(nextTarget * 1.4);
        soundManager.playLevelUp();
        showAlert(`🎉 PARABÉNS! Você subiu para o Nível ${newLevel}!`);

        isaVoiceManager.speak(
          'Uhuuul! Parabéns! Você está ficando um grande fazendeiro!',
          'cheering'
        );

        try {
          confetti({ particleCount: 120, spread: 90, origin: { y: 0.5 } });
        } catch {
          // ignore
        }
      }

      return {
        ...prev,
        level: newLevel,
        xp: newXp,
        nextLevelXp: nextTarget,
      };
    });
  };

  // Advance Mission Progress
  const triggerMissionProgress = (action: IsaMission['requiredAction'], count: number = 1) => {
    setMissions((prev) =>
      prev.map((m) => {
        if (m.requiredAction === action && !m.completed) {
          const newCount = Math.min(m.requiredCount, m.currentCount + count);
          const isDone = newCount >= m.requiredCount;
          if (isDone && !m.completed) {
            soundManager.playLevelUp();
            showAlert(`⭐ Missão Concluída: "${m.title}"! Fale com a Isa para receber a recompensa!`);
            isaVoiceManager.speak(
              'Parabéns pela dedicação! Vem aqui comigo para pegar sua recompensa!',
              'clapping'
            );
          }
          return {
            ...m,
            currentCount: newCount,
            completed: isDone,
          };
        }
        return m;
      })
    );
  };

  // Contextual Interaction Trigger ([E] or Screen Button)
  const handleContextualInteract = async () => {
    lastActivityTimeRef.current = Date.now();
    if (!currentTarget) return;

    if (currentTarget.type === 'isa') {
      soundManager.playIsaHello();
      setIsIsaModalOpen(true);
      triggerMissionProgress('talk', 1);
      return;
    }
    if (currentTarget.type === 'market') {
      soundManager.playPop();
      setIsMarketOpen(true);
      return;
    }
    if (currentTarget.type === 'land') {
      soundManager.playPop();
      setIsLandMarketOpen(true);
      return;
    }
    if (currentTarget.type === 'barn') {
      soundManager.playPop();
      setIsInventoryOpen(true);
      return;
    }
    if (currentTarget.type === 'animal') {
      showAlert('A coleta de produtos dos animais aguarda uma operação segura no Supabase. Nenhum item ou moeda foi alterado.');
      return;
    }
    if (currentTarget.type !== 'plot') return;

    const plotId = Number(currentTarget.id);
    const plot = plots.find((entry) => entry.id === plotId);
    if (!plot) return;

    if (!plot.cropType || plot.stage === 0) {
      const seedKey = `${selectedSeed}_seed`;
      if ((player.inventory[seedKey]?.count || 0) <= 0) {
        soundManager.playPop();
        showAlert(`Sem sementes de ${selectedSeed}! Abra a Loja ou fale com a Isa!`);
        setIsShopOpen(true);
        return;
      }

      const cropMeta = CROPS_CATALOG[selectedSeed];
      const state = await runMarketStateAction(
        `farm:${plotId}:plant`,
        () => performMarketFarmAction(player.id, plotId, 'plant', selectedSeed)
      );
      if (!state) return;

      const plantedPlot = mapPlotsFromMarketState(state).find((entry) => entry.id === plotId);
      if (plantedPlot) networkManager.sendPlotAction(plantedPlot, 'plant', player.nickname);
      soundManager.playPlant();
      addXp(cropMeta.xpReward / 2);
      showAlert(`Você plantou ${cropMeta.name} no talhão #${plotId + 1}; a ação foi salva no Supabase.`);
      if (selectedSeed === 'corn') triggerMissionProgress('plant_corn', 1);
      return;
    }

    if (plot.stage < 3) {
      if (plot.watered) {
        soundManager.playPop();
        showAlert('Esta plantação já está regada e crescendo.');
        return;
      }

      const state = await runMarketStateAction(
        `farm:${plotId}:water`,
        () => performMarketFarmAction(player.id, plotId, 'water')
      );
      if (!state) return;

      const wateredPlot = mapPlotsFromMarketState(state).find((entry) => entry.id === plotId);
      if (wateredPlot) networkManager.sendPlotAction(wateredPlot, 'water', player.nickname);
      soundManager.playWater();
      addXp(10);
      showAlert(`A rega do talhão #${plotId + 1} foi salva no Supabase.`);
      return;
    }

    const harvestedCrop = plot.cropType || 'corn';
    const cropMeta = CROPS_CATALOG[harvestedCrop];
    const state = await runMarketStateAction(
      `farm:${plotId}:harvest`,
      () => performMarketFarmAction(player.id, plotId, 'harvest')
    );
    if (!state) return;

    const clearedPlot = mapPlotsFromMarketState(state).find((entry) => entry.id === plotId);
    if (clearedPlot) networkManager.sendPlotAction(clearedPlot, 'harvest', player.nickname);
    soundManager.playHarvest();
    addXp(cropMeta.xpReward);

    if (harvestedCrop === 'corn') {
      isaVoiceManager.speak(
        'Olha só quanta coisa bonita! Glória a Deus! Nossa fazenda está prosperando!',
        'jumping'
      );
      setCommunityGoal((prev) => {
        const nextCur = Math.min(prev.target, prev.current + 1);
        const isCompleted = nextCur >= prev.target;
        const updatedGoal = { ...prev, current: nextCur, completed: isCompleted };
        networkManager.sendCommunityGoalUpdate(updatedGoal);
        if (isCompleted && !prev.completed) {
          isaVoiceManager.speak(
            'Conseguimos! Glória a Deus! Quando trabalhamos juntos, nossa fazenda fica ainda mais bonita!',
            'dancing'
          );
        }
        return updatedGoal;
      });
      triggerMissionProgress('harvest_corn', 1);
    }

    showAlert(`Colheita de ${cropMeta.name} salva no Supabase. O produto foi adicionado ao inventário; moedas só são creditadas por uma venda confirmada.`);
  };

  // Keyboard shortcut for action [E]
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (typeof e.key === 'string' && e.key.toLowerCase() === 'e') {
        void handleContextualInteract();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentTarget, plots, selectedSeed, player]);

  // Claim Mission Reward
  const handleClaimMissionReward = (missionId: string) => {
    const mission = missions.find((entry) => entry.id === missionId);
    if (!mission || mission.claimed) return;
    showAlert('O resgate de missões aguarda uma operação de progresso e recompensa persistida no Supabase.');
  };

  // Free Seeds from Isa
  const handleGiveFreeSeeds = () => {
    showAlert('O presente de sementes ainda não possui um RPC seguro; nenhum item foi adicionado.');
  };

  // Buy Seeds in Shop
  const handleBuySeed = async (cropType: CropType, _displayPrice: number) => {
    const state = await runMarketStateAction(
      `buy-seed:${cropType}`,
      () => purchaseMarketSeed(player.id, cropType)
    );
    if (!state) return;
    soundManager.playCoin();
    showAlert(`Compra de semente confirmada pelo Supabase: ${CROPS_CATALOG[cropType].name}.`);
  };

  // Buy Feed
  const handleBuyFeed = async () => {
    const state = await runMarketStateAction('buy-feed', () => purchaseMarketFeed(player.id));
    if (!state) return;
    soundManager.playCoin();
    showAlert('Compra de ração confirmada pelo Supabase.');
  };

  // Sell Item in Inventory
  const handleSellItem = (_itemId: string, _count: number) => {
    showAlert('A venda direta ainda não possui um RPC seguro; inventário e saldo não foram alterados.');
  };

  // --- MERCADO HANDLERS ---
  const handleBuyMarketListing = async (listingId: string, quantity: number) => {
    const listing = marketListings.find((entry) => entry.id === listingId);
    if (!listing) {
      showAlert('O anúncio não está mais disponível. Atualize o mercado e tente novamente.');
      return;
    }
    if (!listing.stallId) {
      showAlert('O anúncio não tem uma barraca válida no Supabase.');
      return;
    }

    const operationId = `${listingId}:${quantity}`;
    const pendingKey = `market-buy:${operationId}`;
    if (pendingEconomyActionsRef.current.has(pendingKey)) return;

    let idempotencyKey = marketBuyIdempotencyKeysRef.current.get(operationId);
    if (!idempotencyKey) {
      if (typeof crypto === 'undefined' || typeof crypto.randomUUID !== 'function') {
        showAlert('Este navegador não consegue gerar uma chave segura para a compra.');
        return;
      }
      idempotencyKey = crypto.randomUUID();
      marketBuyIdempotencyKeysRef.current.set(operationId, idempotencyKey);
    }

    pendingEconomyActionsRef.current.add(pendingKey);
    try {
      const result = await purchaseMarketListing(
        player.id,
        listing.stallId,
        listing.productId,
        quantity,
        idempotencyKey
      );
      applyMarketState(result.state);
      marketBuyIdempotencyKeysRef.current.delete(operationId);
      soundManager.playCoin();
      showAlert(result.duplicate
        ? 'Esta compra já estava confirmada; o estado salvo foi sincronizado.'
        : `Compra de ${quantity}x ${listing.productName} confirmada pelo Supabase.`);
    } catch (error) {
      showAlert(error instanceof Error ? error.message : 'Não foi possível confirmar a compra no Supabase.');
    } finally {
      pendingEconomyActionsRef.current.delete(pendingKey);
    }
  };

  const handleInstantSell = (_productId: ProductId, _quantity: number) => {
    showAlert('A venda rápida aguarda um RPC de pagamento com idempotência; inventário e saldo não foram alterados.');
  };

  const handleCreateMarketListing = async (productId: ProductId, quantity: number, pricePerUnit: number): Promise<boolean> => {
    const item = player.inventory[productId];
    if (!item || item.count < quantity) {
      showAlert('Quantidade indisponível na mochila para anunciar!');
      return false;
    }

    const state = await runMarketStateAction(
      `restock:${productId}`,
      () => restockMarketProduct(player.id, productId, quantity, pricePerUnit)
    );
    if (!state) return false;
    soundManager.playPop();
    showAlert(`Anúncio de ${quantity}x ${item.name} confirmado e salvo no Supabase.`);
    return true;
  };

  // --- LANDS & EXPANSION HANDLERS ---
  const handleBuyLand = (_landId: string) => {
    showAlert('A compra de terrenos aguarda um RPC atômico no Supabase; nenhuma moeda foi debitada.');
  };

  const handleAddConstruction = (
    _landId: string,
    _type: 'fence' | 'shed' | 'animal_pen' | 'garden_bed' | 'lantern',
    label: string
  ) => {
    showAlert(`A construção "${label}" ainda não tem persistência no Supabase; nenhuma alteração foi aplicada.`);
  };

  const handleTeleportToLand = (x: number, z: number) => {
    if (engineRef.current) {
      engineRef.current.localPlayer.root.position.set(x, 0, z);
      engineRef.current.playerPos.set(x, 0, z);
      showAlert('📍 Você chegou ao seu terreno!');
    }
  };

  // Community Goal Reward
  const handleClaimCommunityReward = () => {
    if (communityClaimed) return;
    showAlert('A recompensa comunitária aguarda progresso e pagamento persistidos no Supabase.');
  };

  // Quick Chat Send
  const handleSendChat = (text: string) => {
    networkManager.sendChat(text, player.nickname);
    engineRef.current?.localPlayer.setChatBubble(text);
    setTimeout(() => {
      engineRef.current?.localPlayer.setChatBubble(null);
    }, 6000);
    showAlert(`💬 Você disse: "${text}"`);
  };

  // Toggle Sound
  const handleToggleMute = () => {
    const muted = soundManager.toggleMute();
    isaVoiceManager.setVoiceMuted(muted);
    setIsMuted(muted);
  };

  // Admin Actions
  const handleAdminRain = () => {
    soundManager.playWater();
    setPlots((prev) => {
      const next = prev.map((p) => ({ ...p, watered: true }));
      engineRef.current?.updatePlotMeshes(next);
      return next;
    });
    showAlert('🌧️ Chuva mágica administrada! Todos os talhões foram regados!');
  };

  const handleAdminInstantGrow = () => {
    soundManager.playHarvest();
    setPlots((prev) => {
      const next = prev.map((p) => (p.cropType ? { ...p, stage: 3 } : p));
      engineRef.current?.updatePlotMeshes(next);
      return next;
    });
    showAlert('⚡ Crescimento instantâneo! Todas as plantas estão maduras!');
  };

  const activeMission = missions.find((m) => !m.claimed);
  const databaseSeedCosts = Object.fromEntries(
    (marketState?.products ?? [])
      .map((product) => [product.product_id, Number(product.seed_cost)] as const)
      .filter(([productId, cost]) => productId in CROPS_CATALOG && Number.isSafeInteger(cost) && cost > 0)
  ) as Partial<Record<CropType, number>>;

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-sky-200 select-none font-['Nunito',sans-serif]">
      {/* 3D Canvas Mount Point */}
      <div ref={canvasMountRef} className="absolute inset-0 z-0 w-full h-full" />

      {/* Title Screen Overlay */}
      {!isPlaying && (
        <TitleScreen
          onStartGame={handleStartGame}
          playersOnlineCount={playersOnlineCount}
        />
      )}

      {/* Floating Isa Voice Subtitles & Emotion Banner */}
      {isPlaying && (
        <IsaReactionBanner
          speech={isaSubtitles?.text || null}
          animationState={isaSubtitles?.animation || 'idle'}
          onDismiss={() => isaVoiceManager.clear()}
        />
      )}

      {/* In-Game HUD */}
      {isPlaying && (
        <HUD
          player={player}
          communityGoal={communityGoal}
          activeMission={activeMission}
          interactionTarget={currentTarget}
          onInteract={handleContextualInteract}
          onOpenInventory={() => setIsInventoryOpen(true)}
          onOpenShop={() => setIsShopOpen(true)}
  onOpenMarket={() => setIsMarketOpen(true)}
  onOpenOrders={() => setIsMarketOpen(true)}
  onOpenLands={() => setIsLandMarketOpen(true)}
  onOpenMyPlots={() => setIsLandMarketOpen(true)}
  onOpenMyFarm={() => setIsLandMarketOpen(true)}
  onOpenAvatarCustomizer={() => setIsAvatarCustomizerOpen(true)}

          onOpenCommunityGoal={() => setIsCommunityGoalOpen(true)}
          onOpenChat={() => setIsChatOpen(true)}
          onOpenIsaDialogue={() => setIsIsaModalOpen(true)}
          onOpenAdmin={() => setIsAdminOpen(true)}
          onJoystickMove={(vec) => {
            if (engineRef.current) {
              engineRef.current.joystickVector = vec;
            }
          }}
          playersOnlineCount={playersOnlineCount}
          onlinePlayerNames={onlinePlayerNames}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
          floatingAlert={floatingAlert}
          isaSubtitles={isaSubtitles}
          onDismissSubtitles={() => isaVoiceManager.clear()}
        />
      )}

      {/* Modals */}
      <IsaDialogueModal
        isOpen={isIsaModalOpen}
        onClose={() => setIsIsaModalOpen(false)}
        missions={missions}
        onClaimReward={handleClaimMissionReward}
        onGiveFreeSeeds={handleGiveFreeSeeds}
      />

      <InventoryModal
        isOpen={isInventoryOpen}
        onClose={() => setIsInventoryOpen(false)}
        inventory={player.inventory}
        onSellItem={handleSellItem}
        selectedSeed={selectedSeed}
        onSelectSeed={(seed) => {
          setSelectedSeed(seed as CropType);
          showAlert(`🌱 Semente de ${seed} equipada para plantio!`);
        }}
      />

      <ShopModal
        isOpen={isShopOpen}
        onClose={() => setIsShopOpen(false)}
        playerCoins={player.coins}
        seedCosts={databaseSeedCosts}
        onBuySeed={handleBuySeed}
        onBuyFeed={handleBuyFeed}
      />

      <MarketModal
        isOpen={isMarketOpen}
        onClose={() => setIsMarketOpen(false)}
        marketState={marketState}
        playerCoins={player.coins}
        inventory={player.inventory}
        marketListings={marketListings}
        onBuyListing={handleBuyMarketListing}
        onInstantSell={handleInstantSell}
        onCreateListing={handleCreateMarketListing}
      />

      <LandMarketModal
        isOpen={isLandMarketOpen}
        onClose={() => setIsLandMarketOpen(false)}
        lands={lands}
        playerCoins={player.coins}
        playerId={player.id}
        onBuyLand={handleBuyLand}
        onAddConstruction={handleAddConstruction}
        onTeleportToLand={handleTeleportToLand}
      />

      <CommunityGoalModal
        isOpen={isCommunityGoalOpen}
        onClose={() => setIsCommunityGoalOpen(false)}
        goal={communityGoal}
        onClaimCommunityReward={handleClaimCommunityReward}
        claimed={communityClaimed}
      />

      <QuickChatModal
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        onSendMessage={handleSendChat}
      />

      <AvatarCustomizerModal
        isOpen={isAvatarCustomizerOpen}
        onClose={() => setIsAvatarCustomizerOpen(false)}
        currentAvatar={player.avatar}
        onSelectAvatar={(avatarId) => {
          setPlayer((prev) => ({ ...prev, avatar: avatarId }));
          showAlert('Avatar atualizado com sucesso!');
        }}
      />

      {/* PAINEL ADMINISTRATIVO: Apenas aberto se o jogador tiver a role isa_owner */}
      <AdminModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        isOwnerRole={player.role === 'isa_owner'}
        onTriggerRain={handleAdminRain}
        onInstantGrow={handleAdminInstantGrow}
        onAddCoins={(_amount) => {
          showAlert('Crédito administrativo bloqueado: ainda não existe um RPC autenticado e auditável para essa operação.');
        }}
        onResetGoal={() => {
          setCommunityGoal((prev) => ({ ...prev, current: 0, completed: false }));
          showAlert('🔄 Meta coletiva reiniciada para 0!');
        }}
        playersCount={playersOnlineCount}
        onlinePlayerNames={onlinePlayerNames}
        lands={lands}
        marketListings={marketListings}
      />
    </div>
  );
}
