-- =====================================================================
-- 🌽 FAZENDINHA DA ISA - ESQUEMA DE BANCO DE DADOS SUPABASE (POSTGRESQL)
-- =====================================================================
-- Executar este script no SQL Editor do Supabase para criar todas as tabelas,
-- índices e políticas de segurança RLS (Row Level Security).

-- 1. Habilitar extensões úteis
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. Tabela de Jogadores (players)
CREATE TABLE IF NOT EXISTS public.players (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nickname VARCHAR(50) NOT NULL,
    avatar VARCHAR(30) DEFAULT 'leo',
    level INT DEFAULT 1,
    experience INT DEFAULT 0,
    coins INT DEFAULT 100,
    is_admin BOOLEAN DEFAULT FALSE,
    is_banned BOOLEAN DEFAULT FALSE,
    last_seen_at TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Tabela de Inventário dos Jogadores (player_inventory)
CREATE TABLE IF NOT EXISTS public.player_inventory (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    player_id UUID REFERENCES public.players(id) ON DELETE CASCADE,
    item_id VARCHAR(50) NOT NULL,
    category VARCHAR(30) NOT NULL, -- 'seed', 'crop', 'product', 'tool'
    quantity INT DEFAULT 0,
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(player_id, item_id)
);

-- 4. Tabela da Fazenda Compartilhada (farm_world)
CREATE TABLE IF NOT EXISTS public.farm_world (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) DEFAULT 'Fazendinha da Isa',
    level INT DEFAULT 1,
    total_harvests INT DEFAULT 0,
    weather VARCHAR(20) DEFAULT 'sunny', -- 'sunny', 'rainy', 'party'
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Tabela de Talhões da Plantação (farm_plots)
CREATE TABLE IF NOT EXISTS public.farm_plots (
    id INT PRIMARY KEY,
    crop_type VARCHAR(30), -- 'corn', 'carrot', 'tomato', 'pumpkin', 'strawberry'
    stage INT DEFAULT 0, -- 0: vazio, 1: broto, 2: crescendo, 3: maduro
    is_watered BOOLEAN DEFAULT FALSE,
    planted_by UUID REFERENCES public.players(id) ON DELETE SET NULL,
    planted_at TIMESTAMPTZ,
    growth_duration_seconds INT DEFAULT 30,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Tabela de Catálogo de Culturas (crops)
CREATE TABLE IF NOT EXISTS public.crops (
    id VARCHAR(30) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    seed_cost INT DEFAULT 10,
    sell_value INT DEFAULT 25,
    growth_time_seconds INT DEFAULT 30,
    xp_reward INT DEFAULT 15,
    water_multiplier FLOAT DEFAULT 0.7
);

INSERT INTO public.crops (id, name, seed_cost, sell_value, growth_time_seconds, xp_reward, water_multiplier)
VALUES
    ('corn', 'Milho Dourado', 10, 25, 30, 20, 0.7),
    ('carrot', 'Cenoura Crocante', 8, 20, 25, 15, 0.7),
    ('tomato', 'Tomate Vermelhinho', 12, 30, 35, 25, 0.7),
    ('pumpkin', 'Abóbora Gigante', 25, 60, 45, 45, 0.7),
    ('strawberry', 'Morango Doce', 20, 50, 40, 35, 0.7)
ON CONFLICT (id) DO NOTHING;

-- 7. Tabela de Animais da Fazenda (animals)
CREATE TABLE IF NOT EXISTS public.animals (
    id VARCHAR(30) PRIMARY KEY,
    type VARCHAR(30) NOT NULL, -- 'cow', 'chicken', 'pig', 'sheep'
    name VARCHAR(50) NOT NULL,
    hunger INT DEFAULT 50,
    last_fed_at TIMESTAMPTZ DEFAULT NOW(),
    ready_to_produce BOOLEAN DEFAULT TRUE,
    produce_type VARCHAR(30) NOT NULL,
    produce_count INT DEFAULT 1,
    position_x FLOAT DEFAULT 0,
    position_z FLOAT DEFAULT 0
);

INSERT INTO public.animals (id, type, name, hunger, ready_to_produce, produce_type, produce_count, position_x, position_z)
VALUES
    ('cow-1', 'cow', 'Mimosa', 50, TRUE, 'milk', 2, 14, -8),
    ('cow-2', 'cow', 'Estrela', 40, FALSE, 'milk', 1, 17, -11),
    ('chicken-1', 'chicken', 'Pipa', 20, TRUE, 'egg', 3, -13, -12),
    ('chicken-2', 'chicken', 'Carijó', 30, TRUE, 'egg', 2, -16, -14),
    ('pig-1', 'pig', 'Baconzinho', 60, FALSE, 'truffle', 1, 14, 12),
    ('sheep-1', 'sheep', 'Floco', 35, TRUE, 'wool', 2, -14, 11)
ON CONFLICT (id) DO NOTHING;

-- 8. Tabela de Missões da Isa (missions)
CREATE TABLE IF NOT EXISTS public.missions (
    id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    target_count INT DEFAULT 1,
    reward_coins INT DEFAULT 50,
    reward_xp INT DEFAULT 40,
    is_community BOOLEAN DEFAULT FALSE
);

INSERT INTO public.missions (id, title, description, target_count, reward_coins, reward_xp, is_community)
VALUES
    ('mission-welcome', 'Boas-vindas da Isa', 'Converse com a Isa para receber sementes de presente!', 1, 30, 25, FALSE),
    ('mission-plant-corn', 'Plantar Milho', 'Plante 3 sementes de milho nos talhões da horta.', 3, 50, 40, FALSE),
    ('mission-harvest-corn', 'Colheita Dourada', 'Colha 3 espigas de milho prontas para o celeiro.', 3, 60, 50, FALSE),
    ('mission-feed-chicken', 'Galinhas Famintas', 'Alimente as galinhas no galinheiro e recolha ovos frescos!', 2, 70, 60, FALSE),
    ('mission-community-corn', 'Grande Colheita Coletiva', 'Ajude a comunidade a atingir a meta coletiva de milho da fazendinha!', 100, 250, 200, TRUE)
ON CONFLICT (id) DO NOTHING;

-- 9. Tabela de Metas Comunitárias (community_goals)
CREATE TABLE IF NOT EXISTS public.community_goals (
    id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    target INT DEFAULT 100,
    current INT DEFAULT 0,
    reward_coins INT DEFAULT 200,
    reward_xp INT DEFAULT 150,
    completed BOOLEAN DEFAULT FALSE,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.community_goals (id, title, target, current, reward_coins, reward_xp, completed)
VALUES ('goal-corn', 'Grande Colheita de Milho Coletiva', 100, 34, 250, 180, FALSE)
ON CONFLICT (id) DO NOTHING;

-- 10. Tabela de Registro de Atividades e Moderação (game_events)
CREATE TABLE IF NOT EXISTS public.game_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    player_id UUID REFERENCES public.players(id) ON DELETE SET NULL,
    player_nickname VARCHAR(50),
    event_type VARCHAR(50) NOT NULL,
    details JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================================
-- SEGURANÇA E RLS (Row Level Security)
-- =====================================================================
ALTER TABLE public.players ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.player_inventory ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farm_world ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farm_plots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crops ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.animals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.missions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.community_goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.game_events ENABLE ROW LEVEL SECURITY;

-- Políticas de Leitura Pública para Jogadores da Fazenda
CREATE POLICY "Permitir leitura pública de jogadores" ON public.players FOR SELECT USING (true);
CREATE POLICY "Permitir inserção de novo jogador" ON public.players FOR INSERT WITH CHECK (true);
CREATE POLICY "Permitir atualização do próprio perfil" ON public.players FOR UPDATE USING (true);

CREATE POLICY "Permitir leitura dos talhões" ON public.farm_plots FOR SELECT USING (true);
CREATE POLICY "Permitir atualização dos talhões" ON public.farm_plots FOR UPDATE USING (true);

CREATE POLICY "Permitir leitura dos animais" ON public.animals FOR SELECT USING (true);
CREATE POLICY "Permitir atualização dos animais" ON public.animals FOR UPDATE USING (true);

CREATE POLICY "Permitir leitura dos eventos" ON public.game_events FOR SELECT USING (true);
CREATE POLICY "Permitir inserção de eventos" ON public.game_events FOR INSERT WITH CHECK (true);

CREATE POLICY "Permitir leitura de metas comunitárias" ON public.community_goals FOR SELECT USING (true);
CREATE POLICY "Permitir atualização de metas comunitárias" ON public.community_goals FOR UPDATE USING (true);

CREATE POLICY "Permitir leitura de culturas e missões" ON public.crops FOR SELECT USING (true);
CREATE POLICY "Permitir leitura de missões" ON public.missions FOR SELECT USING (true);

-- =====================================================================
-- 11. SISTEMA DE COMPRA DE TERRAS E EXPANSÃO (farm_land)
-- =====================================================================
CREATE TABLE IF NOT EXISTS public.farm_land (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    size_category VARCHAR(30) NOT NULL,
    price INT NOT NULL,
    area_m2 INT NOT NULL,
    unlock_level INT DEFAULT 1,
    owner_id UUID REFERENCES public.players(id) ON DELETE SET NULL,
    owner_name VARCHAR(50),
    status VARCHAR(20) DEFAULT 'available', -- 'available', 'owned', 'locked'
    coord_x FLOAT NOT NULL,
    coord_z FLOAT NOT NULL,
    width FLOAT NOT NULL,
    depth FLOAT NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.farm_land (id, name, description, size_category, price, area_m2, unlock_level, coord_x, coord_z, width, depth)
VALUES
    ('land-lake', 'Terreno Lago Encantado', 'Belo terreno beira-lago com terra fértil.', 'lake_special', 150, 120, 1, 36, -20, 14, 14),
    ('land-orchard', 'Colina das Macieiras', 'Próximo ao pomar, ideal para plantações e frutas.', 'medium', 250, 180, 2, 36, 18, 16, 16),
    ('land-pasture', 'Pasto dos Sonhos', 'Espaçoso para animais e celeiros.', 'pasture_special', 350, 220, 2, -36, -15, 16, 16),
    ('land-crop', 'Grande Safra Fértil', 'Terra roxa fértil para plantio massivo de milho.', 'crop_special', 500, 300, 3, 0, 28, 20, 16),
    ('land-lakeview', 'Mirante Bela Vista', 'O maior terreno da fazenda com visão privilegiada.', 'large', 800, 450, 4, -36, 22, 18, 18)
ON CONFLICT (id) DO NOTHING;

-- 12. Tabela de Construções nos Terrenos (farm_constructions)
CREATE TABLE IF NOT EXISTS public.farm_constructions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    land_id VARCHAR(50) REFERENCES public.farm_land(id) ON DELETE CASCADE,
    owner_id UUID REFERENCES public.players(id) ON DELETE CASCADE,
    construction_type VARCHAR(30) NOT NULL, -- 'fence', 'shed', 'animal_pen', 'garden_bed', 'lantern'
    label VARCHAR(50),
    pos_x FLOAT NOT NULL,
    pos_z FLOAT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 13. Tabela do Mercado da Fazendinha (market_listings)
CREATE TABLE IF NOT EXISTS public.market_listings (
    id VARCHAR(50) PRIMARY KEY,
    seller_id UUID REFERENCES public.players(id) ON DELETE CASCADE,
    seller_name VARCHAR(50) NOT NULL,
    product_id VARCHAR(50) NOT NULL,
    product_name VARCHAR(50) NOT NULL,
    icon VARCHAR(10) DEFAULT '🌾',
    quantity INT NOT NULL CHECK (quantity > 0),
    price_per_unit INT NOT NULL CHECK (price_per_unit > 0),
    total_price INT NOT NULL,
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'sold', 'cancelled'
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 14. Transações Comerciais do Mercado (market_transactions)
CREATE TABLE IF NOT EXISTS public.market_transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    listing_id VARCHAR(50),
    buyer_id UUID REFERENCES public.players(id),
    buyer_name VARCHAR(50) NOT NULL,
    seller_id UUID REFERENCES public.players(id),
    seller_name VARCHAR(50) NOT NULL,
    product_id VARCHAR(50) NOT NULL,
    quantity INT NOT NULL,
    total_cost INT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 15. Carteira e Histórico Financeiro dos Jogadores (player_wallet)
CREATE TABLE IF NOT EXISTS public.player_wallet (
    player_id UUID PRIMARY KEY REFERENCES public.players(id) ON DELETE CASCADE,
    balance INT DEFAULT 100 CHECK (balance >= 0),
    total_earned INT DEFAULT 100,
    total_spent INT DEFAULT 0,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.wallet_transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    player_id UUID REFERENCES public.players(id) ON DELETE CASCADE,
    amount INT NOT NULL,
    type VARCHAR(30) NOT NULL, -- 'earn_harvest', 'earn_market', 'spend_seed', 'spend_land', 'spend_construction'
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 16. Eventos de Reação da ISA (isa_reactions)
CREATE TABLE IF NOT EXISTS public.isa_reactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    player_id UUID REFERENCES public.players(id) ON DELETE SET NULL,
    event_type VARCHAR(50) NOT NULL,
    isa_speech TEXT NOT NULL,
    animation_state VARCHAR(30) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS para novas tabelas
-- 17. Tabela de Compradores Automáticos do Mercado (market_buyers)
CREATE TABLE IF NOT EXISTS public.market_buyers (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(80) NOT NULL,
    role VARCHAR(80) NOT NULL,
    avatar VARCHAR(30) DEFAULT 'bento',
    icon VARCHAR(10) DEFAULT '👨‍🌾',
    personality TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 18. Tabela de Pedidos dos Compradores (market_orders)
CREATE TABLE IF NOT EXISTS public.market_orders (
    id VARCHAR(50) PRIMARY KEY,
    buyer_id VARCHAR(50) REFERENCES public.market_buyers(id) ON DELETE CASCADE,
    dialogue TEXT,
    reward_coins INT NOT NULL,
    reward_xp INT NOT NULL,
    status VARCHAR(20) DEFAULT 'available', -- 'available', 'fulfilled', 'cooldown'
    fulfilled_by UUID REFERENCES public.players(id),
    fulfilled_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.market_order_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id VARCHAR(50) REFERENCES public.market_orders(id) ON DELETE CASCADE,
    product_id VARCHAR(50) NOT NULL,
    product_name VARCHAR(80) NOT NULL,
    icon VARCHAR(10) DEFAULT '🌾',
    quantity INT NOT NULL CHECK (quantity > 0)
);

-- RLS
ALTER TABLE public.market_buyers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.market_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.market_order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Permitir leitura de compradores" ON public.market_buyers FOR SELECT USING (true);
CREATE POLICY "Permitir leitura de pedidos" ON public.market_orders FOR SELECT USING (true);
CREATE POLICY "Permitir atualização de pedidos" ON public.market_orders FOR UPDATE USING (true);
CREATE POLICY "Permitir leitura de itens de pedidos" ON public.market_order_items FOR SELECT USING (true);


